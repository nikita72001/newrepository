# WAPP TO ADD TWO INTEGERS RECEIVED FROM COMMAND LINE ARGUMENTS
# try with multi- except

import sys
try:
	n1 = int(sys.argv[1])
	n2 = int(sys.argv[2])
	res = n1 + n2
	print("res = ", res)
except (IndexError, ValueError):
	print("u need to enter two integers ")