# wapp to create a file if it does not exists
# filename would be supplied by the user.

import os
filename = input("enter filename to create ")
if os.path.exists(filename):
	print(filename, "already exists ")
else:
	f = None
	try:
		f = open(filename, "w")
		print(filename, " created ")
	except Exception as e:
		print("issue" , e)
	finally:
		if f is not None:
			f.close()