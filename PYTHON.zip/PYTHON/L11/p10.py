# wapp to read a data from existing file  
# filename would be supplied by the user.
#data

import os
filename = input("enter filename to read from  ")
if os.path.exists(filename):
	f = None
	try:
		with open(filename) as f:
			data = f.read()
			print(data)
	except Exception as e:
		print("issue", e)
	
else:
	print(filename, "does not exists ")

# arm --> auto resource mgt