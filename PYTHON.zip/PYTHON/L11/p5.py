# wapp to read filename from the user and shoe data on screen

f = None
try:
	filename = input("enter filename to read from ")
	f = open(filename)
	data = f.read()
except FileNotFoundError:
	print(filename,"does not exist ")
else:
	print(data)
finally:
	if f is not None:
		f.close()


# File: it is named location on disk (hdd) to store related data
# example: resume,cv,medical report,project report
#Two types: Text(char) and Binary (audio,video,images)
#file operations: 1)open(try)  2) operations(read/write/append) 3)close(finally) 
# if file is on in same folder we have to give path