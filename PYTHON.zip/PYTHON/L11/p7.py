# wapp to delete a file if it exists
# filename would be supplied by the user.

import os
filename = input("enter filename to delete ")
if os.path.exists(filename):
	os.remove(filename)
	print(filename , "deleted")
else:
	print(filename, "does not exists")