# wapp to accept two integer from CLA and perform ans = n1 / n2
import sys

try:
	n1 = int(sys.argv[1])
	n2 = int(sys.argv[2])
	if n2 == 0:
		raise Exception("2nd number should not be 0")
	res = n1 / n2
except IndexError:
	print("you need to enter two integers")
except ValueError:
	print("you need to enter integers")
except Exception as e:
	print(e)
else:
	print("res = ", res)