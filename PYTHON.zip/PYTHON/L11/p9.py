# wapp to read a data from existing file  
# filename would be supplied by the user.
#data

import os
filename = input("enter filename to read from  ")
if os.path.exists(filename):
	f = None
	try:
		f = open(filename, "r")
		data = f.read()
		print(data)
	except Exception as e:
		print("issue", e)
	finally:
		if f is not None:
			f.close()
else:
	print(filename, "does not exists ")

#w--> write
#r-->read
#a--> append