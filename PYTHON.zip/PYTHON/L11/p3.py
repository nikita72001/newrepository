# wapp to accept two integer from CLA and perform ans = n1 / n2
import sys

try:
	n1 = int(sys.argv[1])
	n2 = int(sys.argv[2])
	res = n1 / n2
except IndexError:
	print("you need to enter two integers")
except ValueError:
	print("you need to enter integers")
except ZeroDivisionError:
	print("2nd number shud not be 0")
else:
	print("res = ", res)
