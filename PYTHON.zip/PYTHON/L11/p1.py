# WAPP TO ADD TWO INTEGERS RECEIVED FROM COMMAND LINE ARGUMENTS
# try with multiple except

import sys
try:
	n1 = int(sys.argv[4])
	n2 = int(sys.argv[2])
	res = n1 + n2
	print("res = ", res)
except IndexError:
	print("u need to enter two integers ")
except ValueError:
	print("you need to enter integers")