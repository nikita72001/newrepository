#exception handeling: to prevent program from abnormal termination

# wapp to read an integer and print "yes" if its ok else "no"

try:
	num = int(input("enter an integer "))
except ValueError:
	print("no")
else:
	print("yes" , num)