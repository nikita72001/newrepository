class employee:
	def __init__(self, eid, ename, epds):
		self.eid = eid
		self.ename = ename
		self.epds = epds
	def __mul__(self, other):
		res = self.epds * other.nodp
		return res
class attendance:
	def __init__(self, nodp):
		self.nodp = nodp

e = employee(10, 'sandip', 500)
a = attendance(26)

sal = e * a
print("sal = ", sal)