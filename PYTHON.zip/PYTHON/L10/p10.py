# wapp to read two integer and find their addition
print("work started")
try:
	num1 = int(input("enter first integer "))
	num2 = int(input("enter second integer "))
except ValueError:
	print("u need to enter integers only ")
else:
	res = num1 + num2
	print("res = ", res)
print("work ended")