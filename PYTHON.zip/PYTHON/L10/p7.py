# wapp to read an integer and print "yes" if its ok else "no"

try:
	num = int(input("enter an integer "))
	print("yes" , num)
except ValueError:
	print("no")