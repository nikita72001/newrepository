# soln to prac1--> single inheritance

class person:
	def __init__(self, id, name, address):
		self.id = id
		self.name = name
		self.address = address
	def show(self):
		print("id = ", self.id )
		print("name = ", self.name )
		print("address = ", self.address )

p = person(10, 'nikita', 'thane')
p.show()

class student(person):
	def __init__(self, id, name, address, marks ):
		super().__init__(id, name, address)
		self.marks = marks
	def show(self):
		super().show()
		print("marks = ", self.marks )
s = student(30, 'mayu', 'thane', 98)
s.show()
	