# soln to prac1--> multilevel inheritance

class person:
	def __init__(self, id, name, address):
		self.id = id
		self.name = name
		self.address = address
	def show(self):
		print("id = ", self.id )
		print("name = ", self.name )
		print("address = ", self.address )

p = person(10, 'nikita', 'thane')
p.show()

class teacher(person):
	def __init__(self, id, name, address, salary ):
		super().__init__(id, name, address)
		self.salary = salary
	def show(self):
		super().show()
		print("salary = ", self.salary )
t = teacher(30, 'mayuri', 'thane', 50000)
t.show()
	
class Hod(teacher):
	def __init__(self, id, name, address, salary, dept ):
		super().__init__(id, name, address, salary )
		self.dept = dept
	def show(self):
		super().show()
		print("dept = ", self.dept )
H = Hod(40, 'sadhna', 'thane', 98000, 'it')
H.show()
	