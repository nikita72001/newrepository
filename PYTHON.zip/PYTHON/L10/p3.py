# method overriding

class employee:
	def __init__(self, id, name, sal):
		self.id = id
		self.name = name
		self.sal = sal
	def bonus(self):
		amt = self.sal * 0.10
		print("amount = " , amt)

class aemployee(employee):
	pass

a = aemployee(10, 'amit', 5000)
a.bonus()

class pemployee(employee):
	def bonus(self):
		amt = self.sal * 0.15
		print("amount =", amt)
p = pemployee(20, 'sumit', 10000)
p.bonus()


class memployee(employee):
	def bonus(self):
		amt = self.sal * 0.20
		print("amount =", amt)
m = memployee(20, 'nikita', 100000)
m.bonus()