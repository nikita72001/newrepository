def calculate(n1,n2):
	res1 = n1 + n2
	res2 = n1 * n2
	return res1,res2

num1 = float(input("enter first number: "))
num2 = float(input("enter second number: "))

ans1, ans2 = calculate(num1,num2)
print("addition =", ans1 )
print("multiplication =", ans2 )


