def compute(n1,n2):
	res = n1 + n2
	return res

num1 = int(input("enter first number: "))
num2 = int(input("enter second number: "))

ans = compute(num1,num2)
print("ans = ", ans)