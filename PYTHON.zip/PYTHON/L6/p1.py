#write the program to read string and write in alphabetical order



s1 = input("enter the string:")
print(s1)

d1 = sorted(s1)
print(d1)

ns1 = "".join(d1)
print(ns1)
