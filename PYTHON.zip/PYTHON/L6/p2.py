# wapp to read two string and find if they are anagrams
#two strings having same letters but different meanings
# heart   earth         fired      fried

s1 = input("enter the string:")
print(s1)

d1 = sorted(s1)
print(d1)

ns1 = "".join(d1)
print(ns1)

s2 = input("enter the string:")
print(s2)

d2 = sorted(s2)
print(d2)

ns2 = "".join(d2)
print(ns2)

print(s1,s2)
print(ns1,ns2)

if ns1 == ns2 :
	print("yes")
else:
	print("no")
	