# wapf to accept as input integer and return its factorial


def fact(num):
	f = 1
	for i in range(1, num+1):
		f = f * i
	return f
num = int(input("enter an integer: "))
if num < 0:
	print("invalid")
else:
	ans = fact(num)
	print("fact = ", ans)