# wap to accept as input two numbers and print their addition and multiplication

def calculate(n1, n2):
	res1 = n1 + n2
	res2 = n1 * n2
	print("addition = ", res1)
	print("multiplication = ", res2)

num1 = float(input("enter first number: "))
num2 = float(input("enter second number: "))

calculate(num1, num2)

#if integer use -->int
#if integer use-->float