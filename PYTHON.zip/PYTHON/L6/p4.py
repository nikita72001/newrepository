# wap to read the integer amd print their addition

def compute(n1,n2):
	res = n1 + n2
	print("res = ", res)

num1 = int(input("enter first number: "))
num2 = int(input("enter second number: "))

compute(num1,num2)