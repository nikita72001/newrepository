# wapp to read tuple of names from user and print the names in reverse alphabetical morder

name = ()

rep = input("do u wish to enter some name y/n ")
while rep == "y":
	n = input("enter name")
	name = name + (n,)
	rep = input("do u wish to enter some name y/n ")

print("original = ", name)

d1 = list(name)        #convert tuple to list
d1.sort(reverse=True)    #cox list can  sort the data
name = tuple(d1)       #convert kiya list ko tuple mein

print("modified ", name)
