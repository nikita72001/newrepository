t3 = 2.3, 4.4, 5.6
print(t3)
print(type(t3))
