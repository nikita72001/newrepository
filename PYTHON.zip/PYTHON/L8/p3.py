# demo for tuple

t1 = (10, 30, 20, 10, 50, 40, 20, 30)
print(t1)
print(type(t1))

t2 = ("amtit", "kamal", "nikita")
print(t2)
print(type(t2))

t3 = 2.3, 4.4, 5.6
print(t3)
print(type(t3))

print(t1 + t2)
print(t1 * 2)
print(t2 * 3)
print("amit" in t2)
print("Nikita" in t2)

#t2.append("akshay")
#t1.pop()                     #-->tuple are immutable this operation are not allowed
#t1.sort()

print(t1.index(30))          # us tuyple mein us element by position
#print(t1.index(34))
print(t1.count(10))            # yeh batayega us tuple mein woh element kitni baar hain
