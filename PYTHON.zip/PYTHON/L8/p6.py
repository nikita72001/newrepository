# wamdp to maintain team names participating in IPL tournaments

team_name = set()

while True:
	op = int(input("1 add team name, 2 remove team name, 3 display and 4 exit "))
	if op == 1:
		name = input("enter team name ")
		len1 = len(team_name)
		team_name.add(name)
		len2 = len(team_name)
		if len2 > len1:
			print(name, " added ")
		else:
			print(name, "already present ")
	elif op == 2:
		name = input("enter team name ")
		len1 = len(team_name)
		team_name.discard(name)
		len2 = len(team_name)
		if len2 < len1:
			print(name, " removed ")
		else:
			print(name, "is not present")
	elif op == 3:
		print("team names = ", team_name)
	elif op == 4:
		break
	else:
		print("invalid")
	