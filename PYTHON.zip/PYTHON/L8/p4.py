
# wapp to read tuple of integer from user and print on screen

data = ()

rep = input("do u wish to enter some data y/n ")
while rep == "y":
	d = int(input("enter data "))
	data = data + (d,)
	rep = input("do u wish to enter some data y/n ")

print(data)
print(type(data))