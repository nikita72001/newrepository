# SET PRACTICE

s1 = {10, 40, 30, 20, 10, 30}
print(s1)
print(type(s1))

# print(s1[0])
print(s1.pop())
s1.discard(40)
print(s1)
s1.remove(30)
print(s1)