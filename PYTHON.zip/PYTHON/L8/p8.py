java = {'amit', 'pooja', 'rumit'}
android = {'vinay', 'amit', 'sunil', 'rakesh'}

# code to find all studnent names
r1 = java | android;           print(r1)
r2 = java.union(android);      print(r2) 

# code to find the common students
r3 = java & android;                  print(r3)
r4 = java.intersection(android);      print(r4) 

# code to find the students in java but not android
r5 = java - android;                  print(r5)
r6 = java.difference(android);        print(r6) 

# code to find the students in android but not java
r7 = android - java;                   print(r7)
r8 = android.difference(java);         print(r8) 
  
  