# wapp to read list of integer and crate even_data,odd_data
# print even_list in ascending and odd_list in descending order

data, even_data, odd_data = [], [], []

rep = input("do u wish to enter some data y/n ")
while rep == "y":
	d = int(input("enter data "))
	data.append(d)
	rep = input("do u wish to enter some data y/n ")

print("data == ", data)

for d in data:
	if d % 2 == 0:     
		even_data.append(d)
	else:
		odd_data.append(d)

even_data.sort()
odd_data.sort(reverse=True)

print("even data == ", even_data)
print("odd data == ", odd_data)	
	
	