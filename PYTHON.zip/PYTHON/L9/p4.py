# waoopp for class student


class student:
	def __init__(self, r, n):
		self.rno = r
		self.name = n
	def talk(self):
		print("my rno is" , self.rno)
		print("my name is " , self.name)

s1 = student(10, "amit")
s1.talk()

s2 = student(20, "sumit")
s2.talk()


#class ==> student --> var(rno & name)  + method(__init__(), talk())
#object -->s1 and s2