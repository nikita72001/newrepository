# wapp to keep a corona count at stationjs in mumbai

corona_counter = {}

while True:
	op = int(input("1 add/new, 2 view, 3 update/modify, 4 remove, and 5 exit "))
	if op == 1:
		station_name = input("enter station name to add ")
		if corona_counter.get(station_name) is None:
			count = int(input("enter count "))
			corona_counter[station_name] = count
			print(station_name, "added ")
		else:
			print(station_name, "already exists")
	elif op == 2:
		print(corona_counter)
	elif op == 3:
		station_name = input("enter station name to update  ")
		if corona_counter.get(station_name) is None:
			print(station_name, "does not exists")
		else:
			count = int(input("enter new  count "))
			corona_counter[station_name] = count
			print(station_name, "updated ")
	elif op == 4:
		station_name = input("enter station name to remove ")
		if corona_counter.get(station_name) is None:
			print(station_name, "does not exists")
		else:
			corona_counter.pop(station_name)
			print(station_name, "removed ")
			
	elif op == 5:
		break
	else:
		print("invalid option ")