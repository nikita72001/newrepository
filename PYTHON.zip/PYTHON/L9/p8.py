# waoop for class student
# var--> rno, name, marks
# method --> info(), find_grades()--> m >= 80--> A, m >=60 --> B else C
 


class student:
	def __init__(self, r, n, m):
		self.rno = r
		self.name = n
		self.marks = m
	def info(self):
		print("rno = ", self.rno)
		print("name = ", self.name)
		print("marks = ", self.marks)

	def find_grade(self):
		if self.marks >= 80:
			print("grade A ")
		elif self.marks >=60:
			print("grade B ")
		else:
			print("grade C")

rno = int(input("enter rno is "))
name = input("enter name is ")
marks = int(input("enter marks is "))

s = student(rno, name, marks)
s.info()
s.find_grade()