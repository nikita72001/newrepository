# waoop for class employee
# var--> id, name, salary
# method --> info(), find_grades()--> m >= 80--> A, m >=60 --> B else C
 


class employee:
	def __init__(self, id, name, salary):
		self.id = id
		self.name = name
		self.salary = salary
	def show(self):
		print("id = ", self.id, "name = ", self.name, "salary = " , self.salary)
	
data = []
while True:
	op = int(input("1 add, 2 view, 3 remove, and 4 exit"))
	if op == 1:
		id = int(input("enter emp id "))
		name = input("enter amp name ")
		salary = float(input("enter emp salary "))
		e = employee(id, name, salary)
		data.append(e)
		print("added")
	elif op == 2:
		for d in data:
			d.show()
	elif op == 3:
		id = int(input("enter emp id to be removed "))
		for d in data:
			if d.id == id:
				data.remove(d)
				print("removed ")
				break
	elif op == 4:
		break
	else:
		print("invalid option ")	