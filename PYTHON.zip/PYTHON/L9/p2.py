# wqp to count occurence of each letter in the given word

#i/p: kkammmal         o/p:{'k':2, 'a',2 :'m':3, 'l':1}

counter = {}

word = input("enter a word")
for w in word:
	c = counter.get(w)
	if c is None:
		counter[w] = 1
	else:
		counter[w] = c + 1

print(counter)