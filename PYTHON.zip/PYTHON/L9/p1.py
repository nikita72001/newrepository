# dictionary demo--> election results,hotel menu, matach scorecard

#declare and initialize

menu = {'idli':50, 'dosa':60, 'pongal':70}
print(menu)
print(type(menu))



#add/update                     # add a key
menu['wada'] = 50
print(menu)

menu['idli'] = 40           #update key
print(menu)

menu.update({'uttapam':70})                # add key
print(menu)

menu.update({'dosa':70})               #update a key
print(menu)

# remove

menu.pop('pongal')
print(menu)

#menu.pop('pizza')

menu.popitem()
print(menu)

menu.clear()
print(menu)
