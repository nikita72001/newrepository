# waopp for class book:
# var--> id, name, price, author           method --> info

class book:
	def __init__(self, i, n, p, a):
		self.id = i
		self.name = n
		self.price = p
		self.author = a
	def info(self):
		print("id = ", self.id)
		print("name = ", self.name)
		print("price = ", self.price)
		print("author = ", self.author)

b1 = book(101, "java", 14000, "kamal sir")
b1.info()