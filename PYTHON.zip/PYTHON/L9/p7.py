''' waoopp for class circle
    vae-->radius
  method  --> show(), area(), circumference() '''

class circle:
	def __init__(self, r):
		self.radius = r
	def show(self):
		print("radius is", self.radius)
	def area(self):
		ans = 3.14 * self.radius * self.radius
		print("area ", ans)
	def circum(self):
		ans = 2 * 3.14 * self.radius
		print("circum is ", ans)

radius = float(input("enter radius "))

c = circle(radius)
c.show()
c.area()
c.circum()