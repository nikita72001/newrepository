''' waoopp for class rectangle
    vae--> length & breadth
  method  --> show(), area(), perimeter() '''

class rectangle:
	def __init__(self, l, b):
		self.length = l
		self.breadth = b
	def show(self):
		print("length is", self.length)
		print("breadth is", self.breadth)
	def area(self):
		ans = self.length * self.breadth
		print("area ", ans)
	def perimeter(self):
		ans = 2 * (self.length + self.breadth)
		print("perimeter is ", ans)

length = float(input("enter length "))
breadth = float(input("enter breadth "))

r = rectangle(length, breadth)
r.show()
r.area()
r.perimeter()