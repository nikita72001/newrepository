from sqlite3 import *
con = None
con = connect("nikitakd.db")
cursor = con.cursor()
rno = input() 
sql1 = "select rno from student"
cursor.execute(sql1)
res = cursor.fetchall()
print(rno)