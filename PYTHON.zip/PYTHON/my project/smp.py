from tkinter import *
from tkinter.messagebox import *
from tkinter.scrolledtext import *
from sqlite3 import *
import matplotlib.pyplot as plt
import requests
import pandas as pd
from bs4 import BeautifulSoup
import random

main_window = Tk()
main_window.title("S. M. S. ")
main_window.geometry("500x500+400+100")
f = ("Calibri", 20, "bold")



def f1():
    add_window.deiconify()
    main_window.withdraw()


def f2():
    main_window.deiconify()
    add_window.withdraw()


def f3():
    view_window_st_data.delete(1.0, END)
    view_window.deiconify()
    main_window.withdraw()
    info = ""
    try:
        con = connect("nikitakd.db")
        cursor = con.cursor()
        sql = "select * from student"
        cursor.execute(sql)
        data = cursor.fetchall()
        for d in data:
            info = info + "rno = " + str(d[0]) + "name= " + str(d[1]) + "marks = " + str(d[2]) + "\n"
        view_window_st_data.insert(INSERT, info)
    except Exception as e:
        con.rollback()
        showerror("ISSUE", e)
    finally:
        if con is not None:
            con.close()


def f4():
    main_window.deiconify()
    view_window.withdraw()

def valid():
    rno = add_window_ent_rno
    if rno.get().isdigit():
        print(rno.get())
        namevalid()
    else:
        showwarning("Invalid","Please Check the Roll no")

def namevalid():
    name = add_window_ent_name
    if name.get().isdigit() != True and name.get() != "" and len(name.get()) >= 2:
        marksvalid()
    else:
        showwarning("Invalid", "Please Check the name")
        pass
def marksvalid():
    marks = add_window_ent_marks
    if  marks.get().isdigit() and int(marks.get()) <= 100:
        f5() 
    else:
        showwarning("Invalid", "Please Check the Marks")
def updatevalid():
    rno = update_window_ent_rno
    if rno.get().isdigit():
        updatenamevalid()
    else:
        showwarning("Invalid", "Please Check the Roll no and No negative number")


def updatenamevalid():
    name = update_window_ent_name
    if name.get().isdigit() != True and name.get() != "" and len(name.get()) >= 2:
        updatemarksvalid()
    else:
        showwarning("Invalid", "Please Check the name and the min length should >= 2")


def updatemarksvalid():
    marks = update_window_ent_marks
    if marks.get().isdigit() and int(marks.get()) <= 100:
        update()
    else:
        showwarning("Invalid", "Please Check the Marks and should not exceed more than 100")

def f5():
    rno = add_window_ent_rno.get()
    name = add_window_ent_name.get()
    marks = int(add_window_ent_marks.get())
    con = None
    try:
        con = connect("nikitakd.db")
        cursor = con.cursor()
        sql = "insert into student values('%s', '%s','%s')"
        cursor.execute(sql % (rno, name, marks))
        con.commit()
        showinfo("success", "Your Record is added to database Successfully")
        print("Your roll no is :"+rno+"\n your Name is: "+name+"\n Your Score is :",marks)
        add_window_ent_rno.delete(0, END)
        add_window_ent_name.delete(0, END)
        add_window_ent_marks.delete(0, END)
        add_window_ent_rno.focus()
        add_window_ent_marks.focus()
    except Exception as e:
        con.rollback()
        print(e)
        showerror("Issue", e)
    finally:
        if con is not None:
            con.close()

def f6():
    update_window.deiconify()
    main_window.withdraw()

def update():
    rno = update_window_ent_rno.get()
    name = update_window_ent_name.get()
    marks = int(update_window_ent_marks.get())
    con = None
    try:
        con = connect("nikitakd.db")
        cursor = con.cursor()
        sql1 = "select rno from student"
        cursor.execute(sql1)
        res = cursor.fetchall()
        if (int(rno),) in res:
            sql = "update student set name='%s',marks='%s' where rno = '%s'"
            cursor.execute(sql % (name, marks, rno))
            con.commit()
            showinfo("success", "Your Record is update in database Successfully")
            update_window_ent_rno.delete(0, END)
            update_window_ent_name.delete(0, END)
            update_window_ent_marks.delete(0, END)
            update_window_ent_rno.focus()
            update_window_ent_marks.focus()
        else:
            showerror("Error", "Record not found")

    except Exception as e:
        con.rollback()
        print(e)
        showerror("Issue" , e)
    finally:
        if con is not None:
            con.close() 
    
def f8():
    main_window.deiconify()
    update_window.withdraw()

def f9():
    delete_window.deiconify()
    main_window.withdraw()

def f10():
    main_window.deiconify()
    delete_window.withdraw()

def delete():
    con = None
    try:
        con = connect("nikitakd.db")
        cursor = con.cursor()
        sql1 = "select rno from student"
        cursor.execute(sql1)
        res = cursor.fetchall()
        print(res)
        rno1 = delete_window_ent_rno.get()
        if (int(rno1),) in res:
            sql = "delete from student where rno ='%s'"
            cursor.execute(sql % (rno1))
            con.commit()
            showinfo("success", "Your record is deleted in database Successfully")
            delete_window_ent_rno.delete(0, END)
            delete_window_ent_rno.focus()
        else:
            showerror("Error", "Record not found")

    except Exception as e:
        con.rollback()
        print(e)
        showerror("Issue", e)
    finally:
        if con is not None:
            con.close()
def f11():
    charts_window.deiconify()
    main_window.withdraw()

def f12():
    main_window.deiconify()
    charts_window.withdraw()

def bargraph():
    con = connect("nikitakd.db")
    cursor = con.cursor()
    sql1 = "select * from student"
    cursor.execute(sql1)
    res = cursor.fetchall()
    showinfo("Information", "Opening Graph")
    name = []
    marks = []
    for line in res:
        name.append(line[1])
        marks.append(line[2])
    plt.bar(name, marks)
    plt.xlabel("Name of The Students")
    plt.ylabel("Scored Marks")
    plt.title("Students Academic Performance")
    plt.show()

def linegraph():
    con = connect("nikitakd.db")
    cursor = con.cursor()
    sql1 = "select * from student"
    cursor.execute(sql1)
    res = cursor.fetchall()
    showinfo("Information", "Opening Graph")
    name = []
    marks = []
    for line in res:
        name.append(line[1])
        marks.append(line[2])
    plt.plot(name, marks, linewidth=3, marker='o', markersize=10)
    plt.xlabel("Name of The Students")
    plt.ylabel("Scored Marks")
    plt.title("Students Academic Performance")
    plt.show()


def location():
    res = requests.get('https://ipinfo.io/')
    data = res.json()
    city = data['city']
    return city

def temp():
    place = location()
    search = f"Weather in {place} "
    url = f"https://www.google.com/search?q={search}"
    r = requests.get(url)
    soup = BeautifulSoup(r.text, "html.parser")
    update = soup.find("div", class_="BNeawe").text
    return update

'''quote = ["First,solve the problem.Then,write the code."," Good things take time",
         "Knowledge is power.","work hard in silence, let your success be your noise"]'''
def qotd():
    wa = "https://www.brainyquote.com/quote_of_the_day"
    res = requests.get(wa)
    data = BeautifulSoup(res.text, "lxml" ).find('img',{'class': 'p-qotd bqPhotoDefault img-responsive'})
    return data['alt']
    print(data['alt'])


   
main_window_btn_add = Button(main_window, background='pink', text="Add", font=f, width=10, command=f1)
main_window_btn_view = Button(main_window, background='pink', text="View", font=f, width=10, command=f3)
main_window_btn_update = Button(main_window, background='pink', text="Update", font=f, width=10, command=f6)
main_window_btn_delete = Button(main_window, background='pink', text="delete", font=f, width=10, command=f9)
main_window_btn_charts = Button(main_window, background='pink', text="charts", font=f, width=10, command=f11)
main_window_lbl_location = Label(main_window, text="Location: " + location(), font=f)
main_window_lbl_location.place(x=10, y=400)
main_window_lbl_temp = Label(main_window, text="Temperature: " + temp(), font=f)
main_window_lbl_temp.place(x=10, y=400)
#main_window_lbl_qotd = Label(main_window, text="Quote of the day: " +random.choice(quote), font=f)
main_window_lbl_qotd = Label(main_window, text="Quote of the day: " +qotd(),font=f)
main_window_lbl_qotd.place(x=10, y=450)
main_window_btn_add.pack(pady=10)
main_window_btn_view.pack(pady=10)
main_window_btn_update.pack(pady=10)
main_window_btn_delete.pack(pady=10)
main_window_btn_charts.pack(pady=10)
main_window_lbl_location.pack(pady=10)
main_window_lbl_temp.pack(pady=10)
main_window_lbl_qotd.pack(pady=10)

add_window = Toplevel(main_window)
add_window.title("Addstudent_data. ")
add_window.geometry("500x500+400+100")

add_window_lbl_rno = Label(add_window, text="Enter rno:", font=f)
add_window_ent_rno = Entry(add_window, bd=5, font=f)
add_window_lbl_name = Label(add_window, text="Enter name", font=f)
add_window_ent_name = Entry(add_window, bd=5, font=f)
add_window_lbl_marks = Label(add_window, text="Enter marks", font=f)
add_window_ent_marks = Entry(add_window, bd=5, font=f)
add_window_btn_save = Button(add_window, background='#f0cdff',text="save", font=f, width=10, command=valid)
add_window_btn_back = Button(add_window,  background='#E06666',text="Back", font=f, width=10, command=f2)
add_window_lbl_rno.pack(pady=10)
add_window_ent_rno.pack(pady=10)
add_window_lbl_name.pack(pady=10)
add_window_ent_name.pack(pady=10)
add_window_lbl_marks.pack(pady=10)
add_window_ent_marks.pack(pady=10)
add_window_btn_save.pack(pady=10)
add_window_btn_back.pack(pady=10)
add_window.withdraw()

view_window = Toplevel(main_window)
view_window.title("View Stu. ")
view_window.geometry("500x500+400+100")

view_window_st_data = ScrolledText(view_window, width=30, height=10, font=f)
view_window_btn_back = Button(view_window,background='#E06666',text="Back", font=f, command=f4)
view_window_st_data.pack(pady=10)
view_window_btn_back.pack(pady=10)
view_window.withdraw()

update_window = Toplevel(main_window)
update_window.title("update data.")
update_window.geometry("500x500+400+100")

update_window_lbl_rno = Label(update_window, text="Enter Rno", font=f)
update_window_ent_rno = Entry(update_window, bd=5, font=f)
update_window_lbl_name = Label(update_window, text="Enter name", font=f)
update_window_ent_name = Entry(update_window, bd=5, font=f)
update_window_lbl_marks = Label(update_window, text="Enter marks", font=f)
update_window_ent_marks = Entry(update_window, bd=5, font=f)
update_window_btn_save = Button(update_window,background='#f0cdff', text="Save", font=f, command=updatevalid)
update_window_btn_back = Button(update_window, background='#E06666',text="Back", font=f, command=f8)
update_window_lbl_rno.pack(pady=10)
update_window_ent_rno.pack(pady=10)
update_window_lbl_name.pack(pady=10)
update_window_ent_name.pack(pady=10)          
update_window_lbl_marks.pack(pady=10)
update_window_ent_marks.pack(pady=10)
update_window_btn_save.pack(pady=10)
update_window_btn_back.pack(pady=10)
update_window.withdraw()

delete_window = Toplevel(main_window)
delete_window.title("delete data.")
delete_window.geometry("500x500+400+100")          
delete_window_lbl_rno = Label(delete_window, text="Enter Rno", font=f)          
delete_window_ent_rno = Entry(delete_window, bd=5, font=f)          
delete_window_btn_save = Button(delete_window,background='#f0cdff', text="Save", font=f, command=delete)
delete_window_btn_back = Button(delete_window,background='#E06666', text="Back", font=f, command=f10)
delete_window_lbl_rno.pack(pady=10)
delete_window_ent_rno.pack(pady=10)
delete_window_btn_save.pack(pady=10)
delete_window_btn_back.pack(pady=10)
delete_window.withdraw()

charts_window = Toplevel(main_window)
charts_window.title("graph data.")
charts_window.geometry("500x500+400+100")
charts_window_btn_line = Button(charts_window,background='#6AA84F', text="Line Chart", font=f, width=10, command=linegraph)
charts_window_btn_bar = Button(charts_window, background='#f0cdff',text="Bar Chart", font=f, width=10, command=bargraph)
charts_window_btn_back = Button(charts_window, background='#E06666',text="Back", font=f, command=f12)
charts_window_btn_line.pack(pady=10)
charts_window_btn_bar.pack(pady=10)
charts_window_btn_back.pack(pady=10)
charts_window.withdraw()


main_window.mainloop()
