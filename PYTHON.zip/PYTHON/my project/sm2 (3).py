from tkinter import *
import tkinter as tk
from tkinter import ttk
import pandas as pd
from tkinter.messagebox import *
from tkinter.scrolledtext import *
import matplotlib.pyplot as plt
from sqlite3 import *


main_window = Tk()
main_window.title("S. M. S. ")
main_window.geometry("500x500+400+100")
f = ("Calibri", 20, "bold")


def f1():
    add_window.deiconify()
    main_window.withdraw()


def f2():
    main_window.deiconify()
    add_window.withdraw()


def f4():
    main_window.deiconify()
    win.withdraw()


def f5():
    rno = add_window_ent_rno.get()
    name = add_window_ent_name.get()
    marks = int(add_window_ent_marks.get())
    con = None
    try:
        con = connect("nikitakd.db")
        cursor = con.cursor()
        sql = "insert into student values('%s', '%s','%s')"
        cursor.execute(sql % (rno, name, marks))
        con.commit()
        showinfo("success", "Your Record is added to database Successfully")
        print("Your roll no is :" + rno + "\n your Name is: " + name + "\n Your Score is :", marks)
        add_window_ent_rno.delete(0, END)
        add_window_ent_name.delete(0, END)
        add_window_ent_marks.delete(0, END)
        add_window_ent_rno.focus()
        add_window_ent_marks.focus()
    except Exception as e:
        con.rollback()
        print(e)
        showerror("Issue", e)
    finally:
        if con is not None:
            con.close()


def f6():
    update_window.deiconify()
    main_window.withdraw()


def f7():
    main_window.withdraw()
    update_window.deiconify()


def f8():
    delete_window.deiconify()
    main_window.withdraw()

def f9():
    main_window.withdraw()
    delete_window.deiconify()

def f10():
    charts_window.deiconify()
    main_window.withdraw()

def f11():
    main_window.withdraw()
    charts_window.deiconify()


def valid():
    rno = add_window_ent_rno
    if rno.get().isdigit():
        print(rno.get())
        namevalid()
    else:
        showwarning("Invalid", "Please Check the Roll no and No negative number")


def namevalid():
    name = add_window_ent_name
    if name.get().isdigit() != True and name.get() != "" and len(name.get()) >= 2:
        marksvalid()
    else:
        showwarning("Invalid", "Please Check the name and the min length should >= 2")


def marksvalid():
    marks = add_window_ent_marks
    if marks.get().isdigit() and int(marks.get()) <= 100:
        f5()
    else:
        showwarning("Invalid", "Please Check the Marks and should not exceed more than 100")


def updatevalid():
    rno = update_window_ent_rno
    if rno.get().isdigit():
        updatenamevalid()
    else:
        showwarning("Invalid", "Please Check the Roll no and No negative number")


def updatenamevalid():
    name = update_window_ent_name
    if name.get().isdigit() != True and name.get() != "" and len(name.get()) >= 2:
        updatemarksvalid()
    else:
        showwarning("Invalid", "Please Check the name and the min length should >= 2")


def updatemarksvalid():
    marks = update_window_ent_marks
    if marks.get().isdigit() and int(marks.get()) <= 100:
        update()
    else:
        showwarning("Invalid", "Please Check the Marks and should not exceed more than 100")


def view():
    win.deiconify()
    main_window.withdraw()
    con = None
    try:
        con = connect("nikitakd.db")
        cursor = con.cursor()
        sql = "SELECT * FROM student"
        cursor.execute(sql)
        rows = cursor.fetchall()
        total = cursor.rowcount
        print("Total Data Entries" + str(total))

        for i in rows:
            tv.insert('', 'end', values=i)
    except Exception as e:
        con.rollback()
        print(e)
        showerror("Issue", e)
    finally:
        if con is not None:
            con.close()


def update():
    rno = update_window_ent_rno.get()
    name = update_window_ent_name.get()
    marks = int(update_window_ent_marks.get())
    con = None
    try:
        con = connect("nikitakd.db")
        cursor = con.cursor()
        sql1 = "select rno from student"
        cursor.execute(sql1)
        res = cursor.fetchall()
        if (int(rno),) in res:
            sql = "update student set name='%s',marks='%s' where rno = '%s'"
            cursor.execute(sql % (name, marks, rno))
            con.commit()
            showinfo("success", "Your Record is update in database Successfully")
            update_window_ent_rno.delete(0, END)
            update_window_ent_name.delete(0, END)
            update_window_ent_marks.delete(0, END)
            update_window_ent_rno.focus()
            update_window_ent_marks.focus()
        else:
            showerror("Error", "Record not found")

    except Exception as e:
        con.rollback()
        print(e)
        showerror("Issue", e)
    finally:
        if con is not None:
            con.close()


def delete():
    con = None
    try:
        con = connect("nikitakd.db")
        cursor = con.cursor()
        sql1 = "select rno from student"
        cursor.execute(sql1)
        res = cursor.fetchall()
        print(res)
        rno1 = delete_window_ent_rno.get()
        if (int(rno1),) in res:
            sql = "delete from student where rno ='%s'"
            cursor.execute(sql % (rno1))
            con.commit()
            showinfo("success", "Your record is deleted in database Successfully")
            delete_window_ent_rno.delete(0, END)
            delete_window_ent_rno.focus()
        else:
            showerror("Error", "Record not found")

    except Exception as e:
        con.rollback()
        print(e)
        showerror("Issue", e)
    finally:
        if con is not None:
            con.close()
def linechart():
    data = pd.read_view()
    name = []
    marks = []
    plt.plot(subject, marks, linewidth=3, marker='o', markersize=10)
    plt.xlabel("name")
    plt.ylabel("Marks")
    plt.title(name + " s Performance")
    plt.grid()
    plt.savefig(name+" .png")
    plt.show()






main_window_btn_add = Button(main_window, text="Add", font=f, width=10, command=f1)
main_window_btn_view = Button(main_window, text="View", font=f, width=10, command=view)
main_window_btn_update = Button(main_window, text="Update", font=f, width=10, command=f6)
main_window_btn_delete = Button(main_window, text="delete", font=f, width=10, command=f8)
main_window_btn_charts = Button(main_window, text="charts", font=f, width=10, command=f10)

main_window_btn_add.pack(pady=10)
main_window_btn_view.pack(pady=10)
main_window_btn_update.pack(pady=10)
main_window_btn_delete.pack(pady=10)
main_window_btn_charts.pack(pady=10)

add_window = Toplevel(main_window)
add_window.title("Addstudent_data. ")
add_window.geometry("500x500+400+100")

add_window_lbl_rno = Label(add_window, text="Enter rno:", font=f)
add_window_ent_rno = Entry(add_window, bd=5, font=f)
add_window_lbl_name = Label(add_window, text="Enter name", font=f)
add_window_ent_name = Entry(add_window, bd=5, font=f)
add_window_lbl_marks = Label(add_window, text="Enter marks", font=f)
add_window_ent_marks = Entry(add_window, bd=5, font=f)
add_window_btn_save = Button(add_window, text="save", font=f, width=10, command=valid)
add_window_btn_back = Button(add_window, text="Back", font=f, width=10, command=f2)
add_window_lbl_rno.pack(pady=10)
add_window_ent_rno.pack(pady=10)
add_window_lbl_name.pack(pady=10)
add_window_ent_name.pack(pady=10)
add_window_lbl_marks.pack(pady=10)
add_window_ent_marks.pack(pady=10)
add_window_btn_save.pack(pady=10)
add_window_btn_back.pack(pady=10)
add_window.withdraw()

update_window = Toplevel(main_window)
update_window.title("Updatestudent_data. ")
update_window.geometry("500x500+400+100")

update_window_lbl_rno = Label(update_window, text="Enter rno:", font=f)
update_window_ent_rno = Entry(update_window, bd=5, font=f)
update_window_lbl_name = Label(update_window, text="Enter name", font=f)
update_window_ent_name = Entry(update_window, bd=5, font=f)
update_window_lbl_marks = Label(update_window, text="Enter marks", font=f)
update_window_ent_marks = Entry(update_window, bd=5, font=f)
update_window_btn_save = Button(update_window, text="update", font=f, width=10, command=updatevalid)
update_window_btn_back = Button(update_window, text="Back", font=f, width=10, command=f7)
update_window_lbl_rno.pack(pady=10)
update_window_ent_rno.pack(pady=10)
update_window_lbl_name.pack(pady=10)
update_window_ent_name.pack(pady=10)
update_window_lbl_marks.pack(pady=10)
update_window_ent_marks.pack(pady=10)
update_window_btn_save.pack(pady=10)
update_window_btn_back.pack(pady=10)
update_window.withdraw()

delete_window = Toplevel(main_window)
delete_window.title("Deletestudent_data. ")
delete_window.geometry("500x500+400+100")

delete_window_lbl_rno = Label(delete_window, text="Enter rno:", font=f)
delete_window_ent_rno = Entry(delete_window, bd=5, font=f)
delete_window_btn_save = Button(delete_window, text="Delete", font=f, width=10, command=delete)
delete_window_btn_back = Button(delete_window, text="Back", font=f, width=10, command=f9)

delete_window_lbl_rno.pack(pady=10)
delete_window_ent_rno.pack(pady=10)
delete_window_btn_save.pack(pady=10)
delete_window_btn_back.pack(pady=10)
delete_window.withdraw()

charts_window = Toplevel(main_window)
charts_window.title("graph_data. ")
charts_window.geometry("500x500+400+100")
charts_window_btn_line = Button(charts_window, text="Line Chart", font=f, width=10, command=linechart)
charts_window_btn_bar = Button(charts_window, text="Bar Chart", font=f, width=10)
charts_window_btn_back = Button(charts_window, text="Back", font=f, command=f11)
charts_window_btn_line.pack(pady=10)
charts_window_btn_bar.pack(pady=10)
charts_window_btn_back.pack(pady=10)
charts_window.withdraw()




win = Tk()
win.title("View Students")
win.geometry("650x500")

frm = Frame(win)
frm.pack(side=tk.LEFT, padx=20)

tv = ttk.Treeview(frm, columns=(1, 2, 3), show="headings", height="20")
tv.pack()

tv.heading(1, text="Roll No")
tv.heading(2, text="Name")
tv.heading(3, text="Marks")
view_window_btn_back = Button(frm, text="Back", font=f, command=f4)
view_window_btn_back.pack(pady=10)
win.withdraw()

main_window.mainloop()
