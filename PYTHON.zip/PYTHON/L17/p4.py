# AGGREGATE FUNCTIONS

import pandas
data = pandas.read_csv("students.csv")
print(data)


m1 = data['MARKS'].max()
d = data[data.MARKS == m1]
print(d)


d = data[data.MARKS == data['MARKS'].max()]
print(d)

# highest marks in mumbai

m = data[data.LOCATION == "MUMBAI"]
d = m[m.MARKS == m['MARKS'].max()]
print(d)

# lowest marks in TE

m = data[data.EYEAR == "TE"]
d = m[m.MARKS == m['MARKS'].min()]
print(d)

# SORT THE DATA AS PER THE DESC ORDER OF MARKS

d = data.sort_values(by="MARKS", ascending=False)
print(d)

# SORT THE DATA AS PER THE ASC ORDER OF NAME

d = data.sort_values(by="NAME",)
print(d)