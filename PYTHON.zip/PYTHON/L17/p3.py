# filtering
# pandas help to read and analyse the data

import pandas

data = pandas.read_csv("students.csv")
print(data)

d = data[data.LOCATION == "MUMBAI"]
print(d)
# find students fron thane
d = data[data.LOCATION == "THANE"]
print(d)

# find students from marks>=80
d = data[data.MARKS >= 80]
print(d)


# find students from thane & marks>=890
d = data[(data.LOCATION == "THANE") & (data.MARKS >= 90)]
print(d)