from tkinter import *
from tkinter.messagebox import *
import matplotlib.pyplot as plt

root = Tk()
root.title("Chart Generator")
root.geometry("500x600+400+50")


def f1():
	name = ent_name.get()
	phy = int(ent_phy.get())
	chem = int(ent_chem.get())
	maths = int(ent_maths.get())
	subject = ["phy", "chem", "maths"]
	marks = [phy, chem, maths]
	plt.plot(subject, marks, linewidth=3, marker='o', markersize=10)
	plt.xlabel("subject")
	plt.ylabel("Marks")
	plt.title(name + " s Performance")
	plt.grid()
	plt.savefig(name+" .png")
	plt.show()

def f2():
	name = ent_name.get()
	phy = int(ent_phy.get())
	chem = int(ent_chem.get())
	maths = int(ent_maths.get())
	subject = ["phy", "chem", "maths"]
	marks = [phy, chem, maths]
	plt.bar(subject, marks)
	plt.xlabel("subject")
	plt.ylabel("Marks")
	plt.title(name + " s Performance")
	plt.grid()
	plt.savefig(name+" .png")
	plt.show()
f  = ("Calibri" , 18, "bold")
lbl_name = Label(root, text="enter name", font=f)
ent_name = Entry(root, bd=5, font=f)
lbl_phy = Label(root, text="enter physics marks", font=f)
ent_phy = Entry(root, bd=5, font=f)
lbl_chem = Label(root, text="enter chem marks", font=f)
ent_chem = Entry(root, bd=5, font=f)
lbl_maths = Label(root, text="enter maths marks", font=f)
ent_maths = Entry(root, bd=5, font=f)

btn_line = Button(root, text="Line Chart", font=f, width=10, command=f1)
btn_bar = Button(root, text="Bar Chart", font=f, width=10, command=f2)

lbl_name.pack(pady=5)
ent_name.pack(pady=5)
lbl_phy.pack(pady=5)
ent_phy.pack(pady=5)
lbl_chem.pack(pady=5)
ent_chem.pack(pady=5)
lbl_maths.pack(pady=5)
ent_maths.pack(pady=5)
btn_line.pack(pady=5)
btn_bar.pack(pady=5)

def wd():
	if askokcancel("Quit","Tussi jaa rahe ho"):
		if askokcancel("sacchi", "are you sure"):
			if askokcancel("sacchi", "pakka na"):
				root.destroy()

root.protocol("WM_DELETE_WINDOW", wd)

root.mainloop()

