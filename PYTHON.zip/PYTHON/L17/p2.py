# SELECTION

import pandas
data= pandas.read_csv("students.csv")
print(data)

print(data.shape)
print(data.head())
print(data.head(2))
print(data.tail())
print(data.tail(3))

print(data[:])
print(data[::])
print(data[4:])
print(data[:3])
print(data[2:6])
print(data[0:8:2])
print(data[1:9:3])
print(data[::-1])