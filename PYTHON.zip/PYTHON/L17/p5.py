import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("medals.csv")

country = data['COUNTRY'].tolist()
gold_medal = data['GOLD_MEDAL'].tolist()

plt.pie(gold_medal, labels=country, autopct="%0.3f%%", explode=[0.1, 0, 0, 0], shadow=True)
plt.title("Olympics performance")
plt.show()