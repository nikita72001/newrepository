 
num = int(input("enter number"))

if num < 0:
	print("invalid")
else:
	print("num = " , num)
	rev = 0
	while num > 0:
		digit = num % 10
		rev = rev * 10 + digit
		num =  num // 10
	print("rev = " , rev)
