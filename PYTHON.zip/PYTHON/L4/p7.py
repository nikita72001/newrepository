# string

s1 = 'nikita mahesh kadam'
print(s1)

s2 = "nikita mahesh kadam"
print(s2)

s3 = ''' g06 kamalkunj kisan nagar no 3 '''
print(s3)

s4 = """kamal kunj kisan nagar"""
print(s4)

t1 = "nikita"
t2 = "kadam"
print(t1 + t2)
print(t1 * 2)
print(t1 * 4)