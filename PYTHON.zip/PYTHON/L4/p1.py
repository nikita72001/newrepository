#WAP TO READ YEAR AND FIND IT IS LEAP YEAR OR NOT
# MULTIPLE BY 4/DIVIDE BY 4

year = int(input("enter the year "))

# logic 1

if year % 4 == 0:
	print("yes")
else:
	print("no")

#logic 2

res = "yes" if year % 4 == 0 else "no"
print(res)

#logic 3

print("yes") if year % 4 == 0 else print("no")