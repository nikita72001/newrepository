for i in range(9,3,-2):
	print(i, end ="  ")