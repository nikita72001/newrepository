''' wap to generate pattern
10
11 11
12 12 12'''

n = int(input("enter the number "))
if n < 0:
	print("invalid")
else:
	k = 10
	for i in range(1 , n+1):
		print(i * (str(k) + "  "))
		k = k + 1