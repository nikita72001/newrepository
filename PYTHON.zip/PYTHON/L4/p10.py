''' wap to generate pattern
A
B B
C C C'''

n = int(input("enter the number "))
if n < 0:
	print("invalid")
else:
	k = 65
	for i in range(1 , n+1):
		print(i * (chr(k) + "  "))
		k = k + 1