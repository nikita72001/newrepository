
# finf max no:
n1 = int(input("enter the first number "))

n2 = int(input("enter the second no "))

if n1 > n2:
	print(n1 , "is max")
else:
	print(n2 , "is max")

#logic 2

print(max(n1,n2), "is max")

# logic 3 for knowlegde max can supply any no of arguments
print(max(10,20,45,23), "is maximum")