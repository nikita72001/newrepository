''' wap to generate pattern
*
* *
* * *'''

n = int(input("enter the number "))
if n < 0:
	print("invalid")
else:
	for i in range(1 , n+1):
		print(i * "* ")