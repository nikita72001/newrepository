# wap to find sum of +ve integer :

num = int(input("enter the number"))
if num < 0:
	print("invalid")
else:
	sum = 0
	for i in range(1, num + 1):
		sum = sum + i
	print("sum = " , sum)
		
	