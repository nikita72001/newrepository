#p4 record view--> static data--> fetchall()

from sqlite3 import *
con = None
try:
	con = connect("kamalclasses.db")
	print("database created/opened ")
	cursor = con.cursor()
	sql = "select * from student"
	cursor.execute(sql)
	data = cursor.fetchone()
	for d in data:
            print("rno= ", data[0], "name = ", data[1], "marks = ", data[2])                           # list of tuple[(), (), ()]
except Exception as e:
	print("issue ", e)
	con.rollback()
finally:
	if con is not None:
		con.close()
		print("closed")