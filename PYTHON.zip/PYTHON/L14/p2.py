#p2 create table

from sqlite3 import *
con = None
try:
	con = connect("kamalclasses.db")
	print("database created/opened ")
	cursor = con.cursor()
	sql = "create table student(rno integer primary key, name varchar(20), marks int)"
	cursor.execute(sql)
	print("table created")
except Exception as e:
	print("issue ", e)
finally:
	if con is not None:
		con.close()
		print("closed")