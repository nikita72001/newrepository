from tkinter import *
from tkinter .messagebox import *
from sqlite3 import *

root = Tk()
root.title("what next ??? ")
root.geometry("500x500+400+100")

f = ("calibri", 30, "bold")
lbl_name = Label(root, text="enter name" , font=f)
ent_name = Entry(root, bd=5, font=f)
lbl_name.grid()
ent_name.grid(padx=10)

k = IntVar()
k.set(1)

lbl_option = Label(root, text="select any one option", font=f)
rb_job = Radiobutton(root, text="JOB", font=f, variable=k, value=1)
rb_ms = Radiobutton(root, text="MS", font=f, variable=k, value=2)
rb_mba = Radiobutton(root, text="MBA", font=f, variable=k, value=3)

lbl_option.grid()
rb_job.grid( sticky="w")
rb_mba.grid( sticky="w")
rb_ms.grid( sticky="w")

def f1():
	na = ent_name.get()
	if k.get() == 1:
		ch = "JOB"
	elif k.get() == 2:
		ch = "MS"
	else:
		ch = "MBA"
	con = None
	try:
		con = connect("wndatabase.db")
		cursor = con.cursor()
		sql = "insert into wn(name, choice) values('%s', '%s')"
		cursor.execute(sql % (na, ch))
		con.commit()
		showinfo("succes", "Thanks for information")
	except Exception as e:
		con.rollback()
		showerror("Mistake", "Check input")
	finally:
		if con is not None:
			con.close()
btn_submit = Button(root, text="Submit", font=f, command = f1)
btn_submit.grid()

root.mainloop()