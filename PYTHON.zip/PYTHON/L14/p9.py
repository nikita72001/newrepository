#p9 record drop --> dynamically data--> user

from sqlite3 import *
con = None
try:
	con = connect("kamalclasses.db")
	print("database created/opened ")
	cursor = con.cursor()
	sql = "drop  table student "
	cursor.execute(sql)
	print("table droped")
except Exception as e:
	print("issue ", e)
	con.rollback()
finally:
	if con is not None:
		con.close()
		print("closed")