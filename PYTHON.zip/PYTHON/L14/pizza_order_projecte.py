from tkinter import *
from tkinter .messagebox import *
from sqlite3 import *

root = Tk()
root.title("piza order ")
root.geometry("500x500+450+100")

f = ("Arial", 40, "bold italic")
lbl_name = Label(root, text="enter name", font=f)
ent_name = Entry(root, bd=5, font=f)
lbl_phone = Label(root, text="enter phone number", font=f)
ent_phone = Entry(root, bd=5, font=f)

lbl_name.grid()
ent_name.grid(padx=10)
lbl_phone.grid()
ent_phone.grid(padx=10)

lbl_toppings = Label(root, text="select ur toppings", font=f)
to, ch, ja, sa  = IntVar(),IntVar(),IntVar(),IntVar()
ch_tomato = Checkbutton(root, text="Tomato", font=f, variable=to)
ch_cheeze = Checkbutton(root, text="Cheeze", font=f, variable=ch)
ch_jalapeno = Checkbutton(root, text="Jalapeno", font=f, variable=ja)
ch_sauce = Checkbutton(root, text="Sauce", font=f, variable=sa)


lbl_toppings.grid()
ch_tomato.grid( sticky="w")
ch_cheeze.grid( sticky="w")
ch_jalapeno.grid(sticky="w")
ch_sauce.grid(sticky="w")

def f1():
	na = ent_name.get()
	ph = ent_phone.get()
	toppings = ""
	if to.get() == 1:
		toppings += " tomato "
	if ch.get() == 1:
		toppings += " cheeze "
	if ja.get() == 1:
		toppings += " jalapeno "
	if sa.get() == 1:
		toppings += " sauce "
	con = None
	try:
		con = connect("pizza_order_database.db")
		cursor = con.cursor()
		sql = "insert into po(name, phone, toppings) values('%s', '%s', '%s')"
		cursor.execute(sql % (na, ph, toppings))
		con.commit()
		showinfo("succes", "Thanks for information")
	except Exception as e:
		showerror("issue", "e")
	finally:
		if con is not None:
			con.close()
btn_order = Button(root, text="Order", font=f, command=f1)
btn_order.grid()
root.mainloop()

