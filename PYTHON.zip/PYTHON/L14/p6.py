#p6 record insert--> dynamically data--> user

from sqlite3 import *
con = None
try:
	con = connect("kamalclasses.db")
	print("database created/opened ")
	cursor = con.cursor()
	sql = "insert into student values('%d', '%s', '%d')"
	rno = int(input("enter rno "))
	name = input("enter name")
	marks = int(input("enter marks "))
	cursor.execute(sql % (rno, name, marks))
	con.commit()
	print("record added succesfully")
except Exception as e:
	print("issue ", e)
	con.rollback()
finally:
	if con is not None:
		con.close()
		print("closed")