#p3 record insert--> static data--> programmer

from sqlite3 import *
con = None
try:
	con = connect("kamalclasses.db")
	print("database created/opened ")
	cursor = con.cursor()
	sql = "insert into student values (20, 'sonali', 80)"
	cursor.execute(sql)
	con.commit()
	print("record added")
except Exception as e:
	print("issue ", e)
	con.rollback()
finally:
	if con is not None:
		con.close()
		print("closed")