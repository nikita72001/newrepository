#p1 create database

from sqlite3 import *
con = None
try:
	con = connect("nikita.db")
	print("database created/opened ")
except Exception as e:
	print("issue ", e)
finally:
	if con is not None:
		con.close()
		print("closed")