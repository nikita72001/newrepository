import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

data = pd.read_csv("jobs.csv")
language = data['LANGUAGE'].tolist()
jobs_2017 = data['JOBS_2017'].tolist()
jobs_2018 = data['JOBS_2018'].tolist()

x = np.arange(len(language))
plt.bar(x, jobs_2017, width=0.25, label="2017", color="blue")
plt.bar(x+0.25, jobs_2018, width=0.25, label="2018", color="green")

plt.xticks(x, language)
plt.xlabel("Languages")
plt.ylabel("Jobs")

plt.legend()
plt.grid()
plt.show()



