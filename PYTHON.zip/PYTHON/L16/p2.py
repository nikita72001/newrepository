# wapp to get the latest corona count

import requests
import bs4
try:
	wa = "https://www.worldometers.info/coronavirus/country/india/"
	res = requests.get(wa)
	print(res)

	data = bs4.BeautifulSoup(res.text, "html.parser")
	#print(data)

	info = data.find_all("div", {"class": "maincounter-number"})
	print(info)

	tc = info[0].span.text;            print("total cases ", tc)
	td = info[1].span.text;            print("total deaths ", td)
	tr = info[2].span.text;            print("total recovery ", tr)
except Exception as e:
	print("issue " , e)