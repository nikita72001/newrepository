# wapp to get quote of the day

import requests
import bs4

try:
	wa = "https://www.brainyquote.com/quote_of_the_day"
	res = requests.get(wa)
	#print(res)

	data = bs4.BeautifulSoup(res.text, "html.parser")
	#print(data)

	info = data.find("img" , {"class":"p-qotd"})
	print(info)

	qotd = info['alt']
	print("aaj ka shubh vichaar = ", qotd)

	# to download the image
	ia = "https://www.brainyquote.com/" + info["data-img-url"]
	res = requests.get(ia)
	f = open("qotd.jpg", "wb")
	f.write(res.content)
	f.close()

except Exception as e:
	print("issue ", e)
