import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("petrol_prices.csv")
print(data)

month = data['MONTH'].tolist()
mumbai = data['MUMBAI'].tolist()
delhi = data['DELHI'].tolist()
chennai = data['CHENNAI'].tolist()

plt.plot(month, mumbai, linewidth=3, marker="o", markersize=10, label="Mumbai")
plt.plot(month, delhi, linewidth=3, marker="o", markersize=10, label="Delhi")
plt.plot(month, chennai, linewidth=3, marker="o", markersize=10, label="Chennai")

plt.xlabel("Months")
plt.ylabel("Prices")
plt.title("Petrol prices")

plt.legend()
plt.grid()

plt.savefig("pp1.png")
plt.savefig("pp2.pdf")


plt.show()