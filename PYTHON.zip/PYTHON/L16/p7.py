import matplotlib.pyplot as plt

subjects = ['mech', 'bee', 'maths']
marks = [78, 98, 82]

plt.bar(subjects, marks)
plt.title("Nikita's performance")
plt.xlabel("Subject")
plt.ylabel("Marks")

plt.show()