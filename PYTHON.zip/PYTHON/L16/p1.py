# wapp to download a file

import requests

try:
	ia = "https://www.smartcitiesworld.net/AcuCustom/Sitename/DAM/013/mumbai_AdobeStock_88429985.jpg"
	res = requests.get(ia)
	print(res)

	f = None
	try:
		f = open("mumbai.jpg", "wb")
		f.write(res.content)
		print("file download")
	except Exception as e:
		print("download issue , e")
	finally:
		if f is not None:
			f.close()
except Exception as e:
		print("issue" , e)