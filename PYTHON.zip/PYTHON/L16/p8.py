import matplotlib.pyplot as plt
import numpy as np

products = ['laptop', 'printer', 'router']
reena = [10, 25, 15]
veena = [5, 30, 12]

x = np.arange(len(products))
plt.bar(x, reena, width=0.25, label="Reena")
plt.bar(x+0.25, veena, width=0.25, label="Veena")
plt.xticks(x, products)

plt.xlabel("Sales")
plt.ylabel("products")
plt.title("Performance Analysis")

plt.legend(shadow=True)
plt.grid()

plt.savefig("pp1.png")

plt.show()