# wapf to find the min of three integers supplied

def find_min(p, q, r):                              # formal parameter
	if p < q:
		res = p
	else:
		res = q
	if r < res:
		res = r
	return res

a = int(input("enter first integer: "))
b = int(input("enter second integer: "))
c = int(input("enter second integer: "))

ans = find_min(a, b, c)                                 # actual par
print("min of three no" , ans)
