def f1(a, b, c=30, d=40):
	print(a, b, c, d)

f1(10, 20)
f1(10, 20, 30)
f1(20, 30, d=40)

#default parameter-->if parameter is pass already no need to pass it again in fun call
#all argument to right of default arg follows only dafault arg
#(a,b=20,c)-->will not work 