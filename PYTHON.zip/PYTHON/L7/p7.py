# wapp to read from users marks obtained by students in a class test
# and find sum of all the marks and find avg marks

marks = []

rep = input("do you want to enter marks of students  y/n ")
while rep == "y":
	m = int(input("enter marks "))
	marks.append(m)
	rep = input("do you want to enter marks of students y/n ")



print("total = " , sum(marks))
print("average = ", sum(marks)/len(marks))