def find_min(a , b):
	if a < b:
		return a
	else:
		return b
a = int(input("enter the first no "))
b = int(input("enter the second no "))

ans = find_min(a , b)
print("find_min=" , ans)