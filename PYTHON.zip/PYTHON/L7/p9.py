# wapp to read from users marks obtained by students in a class test
# and find highest and lowest marks

marks = []

rep = input("do you want to enter marks of students  y/n ")
while rep == "y":
	m = int(input("enter marks "))
	marks.append(m)
	rep = input("do you want to enter marks of students y/n ")

marks.sort()
print("low = " , marks[0])
print("high = " , marks[-1])