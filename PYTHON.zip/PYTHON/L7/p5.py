# wap to keeep track on the food itens order by customer
# list--> collection of data

food_items = []

rep = input("would you like to ordert something y/n ")
while rep == "y":
	name = input("enter food name ")
	food_items.append(name)
	rep = input("would you like to order more y/n ")

print("food items are ", food_items)