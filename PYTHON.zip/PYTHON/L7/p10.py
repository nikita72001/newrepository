# list ko declare and initiakize kaise karneka
data = []
print(data, type(data))

data1 = [10, 30, 40, 50]
print(data1)

data2 = [40, 50, 40]
print(data2)



# list ke sath wale operators
print(data1 + data2)
print(data1 * 2)
print(data2 * 4)
print(10 in data1)
print(11 in data2)

# list is mutable--> u can add and remove element

#list mai add karne ke liye--> append(), extend(), insert()
print(data1)
data1.append(50)
print(data1)
data1.extend([30, 40, 60])
print(data1)
data1.insert(1, 25)
print(data1)

# list mein se element ko nikal ne ka kaise--> remove() , pop(), pop(index), clear(), del
print(data1)
data1.remove(25)
print(data1)
# data1.remove will cause value error
print(data1)
print(data1.pop())
print(data1)
print(data1.pop())
print(data1)
print(data1.pop(3))
print(data1)


del data1[2]
print(data1)

data1.clear()
print(data1)