# wapp to read from users marks obtained by students in a class test
# and find highest and lowest marks

marks = []

rep = input("do you want to enter marks of students  y/n ")
while rep == "y":
	m = int(input("enter marks "))
	marks.append(m)
	rep = input("do you want to enter marks of students y/n ")

high = marks[0]
low = marks[0]

for m in marks:
	if m > high:
		high = m
	if m < low:
		low = m

print("low = " , low)
print("high = " , high)
	