import numpy
N, M = map(int, raw_input().split())

print numpy.eye(N, M, k = 0)
