def calculate(n1,n2):
	res1 = n1 / n2
	res2 = n1 * n2
	return res1, res2
a = int(input("enter the first number "))
b = int(input("enter second number "))

ans = calculate(a, b)
print(ans)