#wap for data structure--> STACK/LIFO (LAST IN FIRST OUT)

stack = []
while True:
	op = int(input("1 push, 2 pop, 3 dispaly and 4 exit "))
	if op == 1:
		ele = int(input("enter element to push "))
		stack.append(ele)
		print(ele, " pushed element is ")
	elif op == 2:
		if len(stack) == 0:
			print("stack is empty ")
		else:
			print("popped element is = ", ele)
	elif op == 3:
		print("stack contents--> ", stack)
	elif op == 4:
		break
	