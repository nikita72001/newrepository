#p3 to demo parameter passing tech

def f1(a, b, c, d):
	print(a, b, c, d)

#pp--> position parameter
f1(10, 20, 30, 40)
f1(30, 40, 50, 60)

#kp-->keyword parameter
f1(a=10, b=20, c=30, d=40)
f1(a=10, c=30, d=40, b=20)

#pp and kp combo
f1(10, 20, c=30, d=40)
f1(10, 20, d=40, c=30)

#note: saare pp pehle and sare kp badmai
#f1(a=10, 20, 30, 40)--> will give error


