# wapf to find the max of two integers supplied

def find_max(p, q):                              # formal parameter
	if p > q:
		return p
	else:
		return q

a = int(input("enter first integer: "))
b = int(input("enter second integer: "))

ans = find_max(a, b)                                 # actual par
print("max of no" , ans)
