from tkinter import*
from tkinter .messagebox import*
from datetime import*

root = Tk()
root.title("Date and Time App")
root.geometry("500x500+450+100")

def f1():
	d = datetime.now().date()
	showinfo("Tarikh", d)
def f2():
	t = datetime.now().time()
	showwarning("samay", t)
def f3():
	dt = datetime.now()
	showerror("dnt", dt)


f = ("arial", 30, "bold")
btn_date = Button(root, text="Date", width=10, font=f,command=f1).pack(pady=20)
btn_time = Button(root, text="Time", width=10, font=f,command=f2).pack(pady=20)
btn_datetime = Button(root, text="Date n Time", width=10, font=f,command=f3).pack(pady=20)
btn_visitus = Button(root, text="Visit Us", width=10, font=f).pack(pady=20)

root.mainloop()