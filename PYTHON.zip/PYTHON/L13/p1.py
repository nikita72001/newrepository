#GUI-->using package-->tkinter
from tkinter import*
root = Tk()
root.title("My first GUI App")
root.geometry("700x200+400+200")

lb1 = Label(root, text="Good Evening", font=('arial', 60, 'bold'), foreground='red')
lb1.pack()

root.mainloop()