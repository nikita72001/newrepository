from tkinter import *
from tkinter .messagebox import*

root = Tk()
root.title("Square Calci")
root.geometry("700x300+450+120")
def sqr():
	try:
		s = ent_number.get()
		n = int(s)
	except ValueError:
		showerror("Mistake", "integers only aloud")
		ent_number.delete(0, END)
		ent_number.focus()
	else:
		r =  n * n
		showinfo("Result", r)
f = ("arial", 30, "bold italic")
lb1_number = Label(root, text="Enter number", font=f)
ent_number = Entry(root, bd=5, font=f)
btn_find = Button(root, text="Find", font=f, command=sqr)

lb1_number.place(x=10, y=10)
ent_number.place(x=300, y=10)
btn_find.place(x=200, y=80)

root.mainloop()
	