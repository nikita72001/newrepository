from tkinter import *
from tkinter .messagebox import*

root = Tk()
root.title("Even Odd Calci")
root.geometry("500x500+450+120")

def eo():
	try:
		s = ent_number.get()
		n = int(s)
	except ValueError:
		showerror("Galat kiya", "integers only aloud")
		ent_number.delete(0, END)
		ent_number.focus()
	else:
		r = "even" if n % 2 == 0 else "odd"
		showinfo("jawaab", r)
f = ("arial", 30, "bold italic")
lb1_number = Label(root, text="Enter number", font=f)
ent_number = Entry(root, bd=5, font=f)
btn_find = Button(root, text="Find", font=f, command=eo)

lb1_number.pack(pady=10)
ent_number.pack(pady=10)
btn_find.pack(pady=10)

root.mainloop()
	