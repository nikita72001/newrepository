from tkinter import *
from tkinter .messagebox import *

root = Tk()
root.title("piza order ")
root.geometry("500x500+400+120")

def f1():
	toppings = ""
	if to.get() == 1:
		toppings += "tomato"
	if ch.get() == 1:
		toppings += "cheeze"
	if ja.get() == 1:
		toppings += "jalapeno"
	if sa.get() == 1:
		toppings += "sauce"
	showinfo("order", toppings)
to, ch, ja, sa  = IntVar(),IntVar(),IntVar(),IntVar()

f = ("Arial", 40, "bold italic")
ch_tomato = Checkbutton(root, text="Tomato", font=f, variable=to)
ch_cheeze = Checkbutton(root, text="Cheeze", font=f, variable=ch)
ch_jalapeno = Checkbutton(root, text="Jalapeno", font=f, variable=ja)
ch_sauce = Checkbutton(root, text="Sauce", font=f, variable=sa)
btn_order = Button(root, text="Order", font=f, command=f1)

ch_tomato.grid(row=0, column=0, sticky="w")
ch_cheeze.grid(row=1, column=0, sticky="w")
ch_jalapeno.grid(row=2, column=0, sticky="w")
ch_sauce.grid(row=3, column=0, sticky="w")
btn_order.grid()

root.mainloop()
