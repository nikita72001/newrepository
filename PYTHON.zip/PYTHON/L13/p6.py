from tkinter import *
from tkinter .messagebox import *

win = Tk()
win.title("what next ??? ")
win .geometry("500x500+400+120")

def f1():
	if k.get() == 1:
		msg = "JOB"
	elif k.get() == 2:
		msg = "MBA"
	else:
		msg = "MS"
	showinfo("your choice",msg)
k = IntVar()
k.set(1)

f = ("Calibri", 40, "bold italic")
rb_job = Radiobutton(win, text="JOB", font=f, variable=k, value=1)
rb_mba = Radiobutton(win, text="MBA", font=f, variable=k, value=2)
rb_ms = Radiobutton(win, text="MS", font=f, variable=k, value=3)
btn_submit = Button(win, text="submit", font=f, command=f1)

rb_job.grid(row=0, column=0, sticky="w")
rb_mba.grid(row=1, column=0, sticky="w")
rb_ms.grid(row=2, column=0, sticky="w")
btn_submit.grid()

win.mainloop()
