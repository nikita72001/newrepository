from tkinter import*

root = Tk()
root.title("Color Me")
root.geometry("400x400+450+100")

def f1():
	root.configure(background="red")
def f2():
	root.configure(background="green")
def f3():
	root.configure(background="blue")

f = ("arial", 30, "bold")
btn_red = Button(root, text="Red", width=10, font=f,command=f1)
btn_green = Button(root, text="Green", width=10, font=f,command=f2)
btn_blue = Button(root, text="Blue", width=10, font=f,command=f3)

btn_red.pack(pady=20)
btn_green.pack(pady=20)
btn_blue.pack(pady=20)

root.mainloop()