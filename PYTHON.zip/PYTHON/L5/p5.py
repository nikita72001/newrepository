#wapp to read a string and find if its palindrome
#palindrome: string that reads same from --> and <--
#nitin, madam, maam, racecar, malayalam,....

s1 = input("Enter a string:")
r1 = s1[::-1]

if s1 == r1:
	print("Palindrome")
else:
	print("Not Palindrome")