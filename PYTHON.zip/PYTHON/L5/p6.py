#wapp to read username and password 
#if username is kamal and password is classes then o/p success else failure

username = input("Enter username: ")
password = input("Enter password: ")

if username == 'NIKITA' and password == 'KADAM':
	print("success")
else:
	print("failure")

#password is visible