#wapp to read username and password 
#if username is kamal and password is classes then o/p success else failure

from getpass import *

username = input("Enter username: ")
password = getpass("Enter password: ")

if username == 'NIKITA' and password == 'KADAM':
	print("success")
else:
	print("failure")

#password not visible
# getpass --> module name which consist
# a method --> getpass() --> jo likhonge woh screen pe nahin dikhega
