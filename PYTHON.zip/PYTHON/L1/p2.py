print("this is lecture 1")
print("today is intro")
print(" and installation")