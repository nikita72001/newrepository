# wap function to add integer

def add(n1, n2):
	res = n1 + n2
	print("res = ",res)

n1 = int(input("enter first integer"))
n2 = int(input("enter second integer"))
add(n1, n2)