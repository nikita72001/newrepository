def mul(n1, n2):
	res = n1 * n2
	print("res = ", res)

n1 = int(input("enter firest integer "))
n2 = int(input("enter second integer "))

mul(n1, n2)