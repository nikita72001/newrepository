print("enter first integer")
s1 = input()
n1 = int(s1)

s2 = input("enter second integer")
n2 = int(s2)

n3 = int(input("enter third integer"))


ans = n1 + n2 + n3
print(" addition of 3 integers = ",ans)