# demo of procedure oriented programming

def f1():
	print("welcome to python")
	print("introduction and installation")
f1()
f1()