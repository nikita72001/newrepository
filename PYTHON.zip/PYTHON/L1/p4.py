# this is will add two integers given by users
print("enter first number")
s1 = input()
n1 = int(s1)

print("enter second number")
s2 = input()
n2 = int(s2)

res = n1 + n2
print("res = ", res)
 