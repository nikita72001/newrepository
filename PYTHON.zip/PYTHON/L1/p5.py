# wapp to accept as input two integer and multiply
n1 = int(input("enter first integer"))
n2 = int(input("enter second integer"))
res = n1 * n2
print("res = ", res)