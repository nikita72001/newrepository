# data types

a = 10
print(a, type(a))


a = 2.31
print(a, type(a))


a = "nikita"
print(a, type(a))

a = 'classes'
print(a, type(a))


a = True
print(a, type(a))
