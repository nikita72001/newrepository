radius = int(input("enter radius"))

area = 3.14 * radius ** 2
circumference = 2 * 3.14 * radius

print("area = ", round(area,4))
print("circumference = ", round(circumference,3))