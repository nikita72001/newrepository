# swap values

_ = int(input("enter first integer"))
__ = int(input("enter second integer"))
___ = _ + __

print(___)

