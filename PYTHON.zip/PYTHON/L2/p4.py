# swap values

And = int(input("enter first integer"))
OR = int(input("enter second integer"))
ELSE = And + OR

print(ELSE)

