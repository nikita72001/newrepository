# write a program to read amount in dollars and convert into rupees
#if possible print currency


dollars = float(input("enter amount"))
rupees = dollars * 72.53

print("dollars = /U0024 " , dollars)
print("rupees = /U20B9" , rupees)

print("dollars = /U0024 " , round(dollars,4))
print("rupees = /U20B9" , round(rupees,4))