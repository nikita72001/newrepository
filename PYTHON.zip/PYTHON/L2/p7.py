print("enter first integer")
s1 = input()
n1 = int(s1)

s2 = input("enter second integer")
n2 = int(s2)

n3 = int(input("enter third integer"))


sum = n1 + n2 + n3
avg = sum / 3
print(" sum =  ", sum)
print(" avg =  ", avg)