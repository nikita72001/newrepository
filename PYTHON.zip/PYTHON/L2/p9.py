#WAP TO ASSIGN NUMBERS AND EXCHANGE THEIR NUMBERS

print("enter first integer")
s1 = input()
n1 = float(s1)


print("enter second integer")
s2 = input()
n2 = float(s2)

print("n1 = " , n1, "n2 = " , n2)

n3 = n1
n1 = n2
n2 = n3

print("n1 = " , n1, "n2 = " , n2)
 