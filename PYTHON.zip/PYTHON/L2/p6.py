# WAP TO READ TEMP INTO FAR AND CONVERT  INTO CELSIUS 

fah = float(input("enter temp in fah "))
cel = (fah - 32) * 5 / 9

print("fah = ", fah)
print("cel = ", cel)