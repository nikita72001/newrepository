# swap values

n1 = float(input("enter first integer "))
n2 = float(input("enter second integer "))

print("n1 = " , n1 , "n2 = " , n2)

n1 , n2 = n2 , n1

print("n1 = " , n1 , "n2 = " , n2)
  