import requests

try:
	wa = "https://api.coindesk.com/v1/bpi/currentprice.json"
	res = requests.get(wa)
	print(res)

	data = res.json()
	print(data)
# write code to find rates in gbp and eur
	gbp_rate = data['bpi']['GBP']['rate']
	print("GBP Rate = ", gbp_rate)

	eur_rate = data['bpi']['EUR']['rate']
	print("EUR Rate = ", eur_rate)

except Exception as e:
	print("issue ", e)