import requests

try:
	wa = "http://ipinfo.io/"
	res = requests.get(wa)
	print(res)

	data = res.json()
	print(data)

	city_name = data['city']
	print("city name = ", city_name)

	state_name = data['region']
	print("state name = ", state_name)
        
        # write code to find and print the latitude and longitude
	loc = data['loc']
	print(loc)
	info = loc.split(",")
	print("lat = ", info[0])
	print("lon = ", info[1])

except Exception as e:
	print("issue ", e)