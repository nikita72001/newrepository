import requests
try:
	city_name = input("enter city name")
	a1 = "http://api.openweathermap.org/data/2.5/weather?units=metric"
	a2 = "&q=" + city_name
	a3 = "&appid=" + "c6e315d09197cec231495138183954bd"
	wa = a1 + a2 + a3

	res = requests.get(wa)
	print(res)

	data = res.json()
	print(data)

	temp = data['main']['temp']
	print("temp = ", temp)

except Exception as e:
	print("issue ", e)