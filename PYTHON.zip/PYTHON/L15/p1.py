from tkinter import *
from tkinter .messagebox import *
from tkinter .scrolledtext import *
from sqlite3 import *

def f1():
	add_window.deiconify()
	main_window.withdraw()
def f2():
	main_window.deiconify()
	add_window.withdraw()
def f3():
	view_window_st_data.delete(1.0, END)
	view_window.deiconify()
	main_window.withdraw()
	info = ""
	try:
		con = connect("kamalclasses.db")
		cursor = con.cursor()
		sql = "select * from student"
		cursor.execute(sql)
		data = cursor.fetchall()
		for d in data:
			info = info + "rno = " + str(d[0]) + "name = " + str(d[1]) +  "\n"
		view_window_st_data.insert(INSERT,info)
	except Exception as e:
		showerror("ISSUE",e)
	finally:
		if con is not None:
			con.close()
def f4():
	main_window.deiconify()
	view_window.withdraw()
def f5():
	con = None
	try:
		con = connect("kamalclasses.db")
		cursor = con.cursor()
		sql = "insert into student values('%d', '%s')"
		rno = int(add_window_ent_rno.get())
		name = add_window_ent_name.get()
		cursor.execute(sql % (rno,name))
		con.commit()
		showinfo("success","record added")
		add_window_ent_rno.delete(0, END)
		add_window_ent_name.delete(0, END)
		add_window_ent_rno.focus()
	except Exception as e:
		con.rollback()
		showerror("Issue, e")
	finally:
		if con is not None:
			con.close()

main_window = Tk()
main_window.title("S. M. S. ")
main_window.geometry("500x500+400+100")
f = ("Calibri", 20, "bold")

main_window_btn_add = Button(main_window, text="Add", font=f, width=10, command=f1)
main_window_btn_view = Button(main_window, text="View", font=f, width=10, command=f3)

main_window_btn_add.pack(pady=10)
main_window_btn_view.pack(pady=10)

add_window = Toplevel(main_window)
add_window.title("Add Stu. ")
add_window.geometry("500x500+400+100")

add_window_lbl_rno = Label(add_window, text="enter rno:", font=f)
add_window_ent_rno = Entry(add_window, bd=5, font=f)
add_window_lbl_name = Label(add_window, text="enter name:", font=f)
add_window_ent_name = Entry(add_window, bd=5, font=f)
add_window_btn_save = Button(add_window, text="save", font=f, width=10, command=f5)
add_window_btn_back = Button(add_window, text="Back", font=f, width=10, command=f2)
add_window_lbl_rno.pack(pady=10)
add_window_ent_rno.pack(pady=10)
add_window_lbl_name.pack(pady=10)
add_window_ent_name.pack(pady=10)
add_window_btn_save.pack(pady=10)
add_window_btn_back.pack(pady=10)
add_window.withdraw()

view_window = Toplevel(main_window)
view_window.title("View Stu. ")
view_window.geometry("500x500+400+100")

view_window_st_data = ScrolledText(view_window, width=30, height=10,font=f)
view_window_btn_back = Button(view_window, text="Back", font=f, command=f4)
view_window_st_data.pack(pady=10)
view_window_btn_back.pack(pady=10)
view_window.withdraw()

main_window.mainloop()


