# WAP TO READ NUMBER IS EVEN OR ODD

num = int(input("enter the integer"))

# logic no 1

res = num % 2
if res == 0:
	print("even")
else:
	print("odd")

# logic no 2

if num % 2 == 0:
	print("even")
else:
	print("odd")