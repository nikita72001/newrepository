num = int(input("enter number"))

if num < 0:
	print("invalid")
else:
	sum , i = 0 , 1
	i = 1
	while i <= num:
		sum += i
		i += 1
	print("sum = " , sum)
