
# wap to read integer and find sum of digit

num = int(input("enter number"))

if num < 0:
	print("invalid")
else:
	sum = 0
	while num > 0:
		digit = num % 10
		sum = sum + digit
		num =  num // 10
	print("sum = " , sum)
