
length = float(input("enter the length "))
breadth = float(input("enter the breadth ")) 

area = length * breadth
perimeter = 2 * (length + breadth)

print("area = " , area)
print("perimeter = " , perimeter)