print("enter first integer")
s1 = input()
n1 = int(s1)

s2 = input("enter second digit")
n2 = int(s2)

n3 = int(input("enter thired integer"))

sum = n1 + n2 + n3

product = n1 * n2 * n3

print("sum = " , sum)
print("product = " , product)