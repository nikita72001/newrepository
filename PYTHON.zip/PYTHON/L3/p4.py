# wap to read minimum of two num

n1 = int(input("enter first integer"))

n2 = int(input("enter second integer"))

if n1 < n2:
	print(" minimum no is " , n1)
else:
	print(" minimum no is " , n2)

# logic 2
print( min(n1, n2), "is min")