


# WAPTO READ GRADE 




marks = int(input("enter the marks"))

if marks < 0 or marks > 100:
	print("invalid")
elif marks >= 80:
	print(" grade A")
elif marks >= 60:
	print(" grade B")
elif marks >= 40:
	print(" grade C")
else:
	print(" grade D")