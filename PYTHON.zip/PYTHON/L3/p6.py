# wap to find sum of n +ve integer
num = int(input("enter number"))

if num < 0:
	print("invalid")
else:
	sum = 0
	i = 1
	while i <= num:
		sum = sum + i
		i = i + 1
	print("sum = " , sum)
