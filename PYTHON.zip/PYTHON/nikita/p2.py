# Python program to demonstrate in-built poly-
# morphic functions

# len() being used for a string
print(len("HELLO WORLD"))

# len() being used for a list
print(len([10, 20, 30]))
