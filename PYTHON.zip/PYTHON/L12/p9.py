import mypack1.mymath
mypack1.mymath.square(4)
mypack1.mymath.cube(3)



from mypack1.mymath import *
square(4)
cube(3)