# wapp to read radius from user
# use matuh module wherever possible

from math import *

radius = float(input("enter the radiuss "))

area = pi * pow(radius, 2)

circumference = 2 * pi * radius

print("area = ", area)
print("circumference = ", circumference)