def square(num):
	res = num * num
	print("square = " , res)

def cube(num):
	res = num * num * num
	print("cube = ", res)