import mymath
mymath.square(4)
mymath.cube(3)

from mymath import square, cube
square(5)
cube(2)

from mymath import *
square(4)
cube(3)