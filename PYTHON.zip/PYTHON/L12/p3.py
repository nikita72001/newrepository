import math
print(math.pi)
print(math.ceil(4.4))
print(math.floor(4.4))
print(math.ceil(6.6))
print(math.floor(8.4))
print(math.pow(2, 3))

from math import pi, ceil, floor, pow
print(pi)
print(ceil(4.4))
print(floor(4.4))
print(ceil(6.6))
print(floor(8.4))
print(pow(2, 3))

from math import *
print(pi)
print(ceil(4.4))
print(floor(4.4))
print(ceil(6.6))
print(floor(8.4))
print(pow(2, 3))