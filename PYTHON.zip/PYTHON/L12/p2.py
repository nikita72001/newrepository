import os
import pickle

class student:
	def __init__(self, rno, name):
		self.rno = rno
		self.name = name
	def talk(self):
		print("rno = ", self.rno)
		print("name = ", self.name)

data = []

if os.path.exists("student_ka_data.txt"):
	f = open("student_ka_data.txt", "rb")
	data = pickle.load(f)
	f.close()
while True:
	op = int(input("1 create, 2 view, 3 remove, 4 exit\nEnter your choice: "))
	if op == 1:
		rno = int(input("Enter RollNo: "))
		name = input("Enter name: ")
		s = student(rno, name)
		data.append(s)
		print("record added")
	elif op == 2:
		for d in data:
			d.talk()
	elif op == 3:
		r = int(input("Enter roll no. to be removed"))
		for d in data:
			if d.rno == r:
				data.remove(d)
				print("record removed")
				break
	elif op == 4:
		f = open("student_ka_data.txt", "wb")
		pickle.dump(data, f)
		f.close()
		break
	else:
		print("Invalid Choice")
