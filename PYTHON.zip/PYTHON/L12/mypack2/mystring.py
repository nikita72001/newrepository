def touppercase(s):
	res = s.upper()
	return res

def tolowercase(s):
	res = s.lower()
	return res