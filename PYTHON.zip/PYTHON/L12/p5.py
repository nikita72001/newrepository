import random

print(random.randrange(5))
print(random.randrange(3, 8))
print(random.randrange(2, 12, 2))


print(random.random())

print(random.randint(4, 8))