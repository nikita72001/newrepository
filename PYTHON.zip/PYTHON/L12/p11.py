import mypack3.mystring
print(mypack3.mystring.touppercase("nikita"))
print(mypack3.mystring.tolowercase("NIKITA"))

from mypack3.mystring import *
print(touppercase("nikita"))
print(tolowercase("NIKITA"))