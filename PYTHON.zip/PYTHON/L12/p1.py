#wapp  for operations 1 create 2 delete 3 write 4 read 5 exit

import os

while True:
	op = int(input("1 create, 2 delete, 3 write, 4 read and 5 Exit "))
	if op == 1:
		filename = input("enter file name to be created ")
		if os.path.exists(filename):
			print(filename, "already exists ")
		else:
			f = open(filename, "w")
			print(filename, "created")
			f.close()
	elif op == 2:
		filename = input("enter file name to be deleted ")
		if os.path.exists(filename):
			os.remove(filename)
			print(filename, "deleted ")
		else:
			print(filename, "does not exist")
	elif op == 3:
		filename = input("enter file name to written into ")
		if os.path.exists(filename):
			f = open(filename, "a")
			data = input("enter data ")
			f.write(data + "\n")
			f.close()
		else:
			print(filename, "does not exist")
	elif op == 4:
		filename = input("enter file name to read into ")
		if os.path.exists(filename):
			f = open(filename, "r")
			data = f.read()
			print(data)
			f.close()
		else:
			print(filename, "does not exist")
	elif op == 5:
		break
	else:
		print("invalid option")
	
		
			
		