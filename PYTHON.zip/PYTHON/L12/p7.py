from datetime import *

d = datetime.now()
print(d)

d1 = datetime.now().date()
print(d1)

t1 = datetime.now().time()
print(t1)

print(d.day)
print(d.month)
print(d.year)
print(d.hour)
print(d.minute)
print(d.second)


# diplay today's day Mon to sun
print(d.strftime('%a'))
print(d.strftime('%A'))


# display current month Jan to Dec
print(d.strftime('%b'))
print(d.strftime('%B'))