movie = ["dilwale", "kal ho na ho", "kuch kuch hota hai", "kkk", "dear zindagi", "jabtak hai jaan"]

import random
r1 = random.randrange(len(movie))
print(movie[r1])



# try using from random import*

from random import *
r2 = randrange(len(movie))
print(movie[r2])

# try using randint
r3 = randint(0, len(movie)-1)
print(movie[r3])
