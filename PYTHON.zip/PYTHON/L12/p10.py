import mypack2.mystring
print(mypack2.mystring.touppercase("nikita"))
print(mypack2.mystring.tolowercase("NIKITA"))

from mypack2.mystring import *
print(touppercase("nikita"))
print(tolowercase("NIKITA"))