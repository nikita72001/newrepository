n = int(input("enter the no: "))
print(n)
if n % 2 :
    print("weird")
elif  2 <= n <= 5:
    print("not weird")
elif 6 <= n <= 20:
    print(" weird")
else :
    print("not weird")
