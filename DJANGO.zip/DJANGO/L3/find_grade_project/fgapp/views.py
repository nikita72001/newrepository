from django.shortcuts import render

def home(request):
       if request.GET.get("marks"):
                marks = int(request.GET.get("marks"))
                if marks >=80:
                        grade = "Grade A"
                elif marks >=60:
                        grade = "Grade B"
                else:
                        grade = "Grade C"
                return render(request,"home.html",{"grade":grade})
       return render(request,"home.html")
