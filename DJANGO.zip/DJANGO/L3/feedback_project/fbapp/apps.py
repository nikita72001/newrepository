from django.apps import AppConfig


class FbappConfig(AppConfig):
    name = 'fbapp'
