from django.shortcuts import render

def home(request):
       if request.GET.get("f1"):
               msg = request.GET.get("f1")
               print("msg")
               return render(request,"home.html",{"msg":"thanx for response"})
       return render(request,'home.html')

# Create your views here.
