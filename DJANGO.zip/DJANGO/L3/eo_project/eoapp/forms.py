from django import  forms
class EoForm(forms.Form):
        number = forms.IntegerField(label="enter number")