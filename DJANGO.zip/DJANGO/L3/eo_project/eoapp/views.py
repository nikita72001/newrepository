from django.shortcuts import render
from .forms import EoForm
def home(request):
       if request.GET.get("number"):
               num = int(request.GET.get("number"))
               res = "even" if num % 2 == 0 else "odd"
               fm = EoForm()
               return render(request, "home.html",{'fm':fm, "msg":res})
       else:
               fm = EoForm()
               return render(request, "home.html",{'fm':fm})
               

# Create your views here.
