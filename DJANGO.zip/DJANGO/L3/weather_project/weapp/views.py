from django.shortcuts import render
import requests
def home(request):
       if request.GET.get("city"):
               try:
                         city = request.GET.get("city")
                         a1 = "http://api.openweathermap.org/data/2.5/weather?units=metric"
                         a2 = "&q=" + city
                         a3 = "&appid=" + "c6e315d09197cec231495138183954bd"
                         wa = a1 + a2 + a3
                         res = requests.get(wa)
                         data = res.json()
                         temp = data['main']['temp']
                         return render(request,"home.html",{"msg":temp})
               except Exception:
                         return render(request,"home.html",{"msg":"city name not found"})

       return render(request, "home.html")
                          
# Create your views here.
