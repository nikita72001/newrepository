from django.apps import AppConfig


class WeappConfig(AppConfig):
    name = 'weapp'
