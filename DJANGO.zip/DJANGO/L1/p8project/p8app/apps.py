from django.apps import AppConfig


class P8AppConfig(AppConfig):
    name = 'p8app'
