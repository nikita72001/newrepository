from django.apps import AppConfig


class P4AppConfig(AppConfig):
    name = 'p4app'
