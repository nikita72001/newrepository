from django.apps import AppConfig


class P6AppConfig(AppConfig):
    name = 'p6app'
