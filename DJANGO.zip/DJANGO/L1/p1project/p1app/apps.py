from django.apps import AppConfig


class P1AppConfig(AppConfig):
    name = 'p1app'
