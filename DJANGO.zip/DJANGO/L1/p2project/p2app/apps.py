from django.apps import AppConfig


class P2AppConfig(AppConfig):
    name = 'p2app'
