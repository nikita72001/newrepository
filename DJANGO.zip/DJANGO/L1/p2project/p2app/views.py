from django.shortcuts import render
from django.http import Httpresponse

def home(request):
	<html>
        <center>
                <h1 style= "font-size:100px;color:red;"> HELLO NIKKI</h1>
        </center>
        </html>
              
       
# Create your views here.
