from django.apps import AppConfig


class P3AppConfig(AppConfig):
    name = 'p3app'
