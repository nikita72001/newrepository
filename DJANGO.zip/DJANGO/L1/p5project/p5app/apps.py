from django.apps import AppConfig


class P5AppConfig(AppConfig):
    name = 'p5app'
