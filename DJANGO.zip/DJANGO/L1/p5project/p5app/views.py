from django.shortcuts import render

def home(request):
        if request.GET.get('r'):
                 return render(request, 'home.html',{'co':'red'})
        elif request.GET.get('g'):
                 return render(request, 'home.html',{'co':'green'})
        elif request.GET.get('b'):
                 return render(request, 'home.html',{'co':'blue'})
        else: 
                 return render(request,'home.html')


# Create your views here.
