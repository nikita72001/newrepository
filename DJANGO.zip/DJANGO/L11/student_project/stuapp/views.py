from django.shortcuts import render, Http404
from .models import StudentModel
from .serializers import StudentSerializer
from rest_framework.response import Response
from rest_framework.decorators import api_view


@api_view(['GET','POST'])
def stuop(request, id=None):
	if request.method == "GET":
		if id is None:
			result = StudentModel.objects.all()
			sresult = StudentSerializer(result, many=True)
			return Response(sresult.data)
		else:
			try:
				result = StudentModel.objects.all(rno=id)
				sresult = StudentSerializer(result)
				return Response(sresult.data)
			except StudentModel.DoesNotExist:
				raise Http404
	elif request.method == "POST":
		stu = StudentSerializer(data = request.data)
		if stu.is_valid():
			stu.save()
			return Response({"msg":"record created"})
		else:
			return Response(stu.errors)
				


# Create your views here.
