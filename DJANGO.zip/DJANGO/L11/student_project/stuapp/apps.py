from django.apps import AppConfig


class StuappConfig(AppConfig):
    name = 'stuapp'
