import requests
try:
	while True:
		op = int(input("1 date & time, 2 date, 3 time and 4 exit "))
		if op == 1:
			wa = "http://127.0.0.1:8000/"
			res = requests.get(wa)
			data = res.json()
			msg = data['msg']
			print(msg)
		elif op == 2:
			wa = "http://127.0.0.1:8000/dt"
			res = requests.get(wa)
			data = res.json()
			msg = data['msg']
			print(msg)
		elif op == 3:
			wa = "http://127.0.0.1:8000/ti"
			res = requests.get(wa)
			data = res.json()
			msg = data['msg']
			print(msg)
		elif op == 4:
			break
		else:
			print("invalid option")

except Exception as e:
	print("issue", e)