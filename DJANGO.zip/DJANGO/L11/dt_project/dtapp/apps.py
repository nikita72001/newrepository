from django.apps import AppConfig


class DtappConfig(AppConfig):
    name = 'dtapp'
