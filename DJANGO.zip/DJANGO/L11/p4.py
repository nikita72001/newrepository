import requests

try:
	while True:
		op = int(input("1 create, 2 read all, 3 read specific rno and 4 exit "))
		if op == 1:
			rno = int(input("enter rno = "))
			name = input("enter name ")
			marks = int(input(" enter marks "))
			stu = ({"rno":rno, "name":name, "marks":marks})
			wa = "http://127.0.0.1:8000/stuop"
			res = requests.post(wa,stu)
			data = res.json()
			print(data)
		elif op == 2:
			wa = "http://127.0.0.1:8000/stuop"
			res = requests.get(wa)
			data = res.json()
			print(data)
		elif op == 3:
			r = int(input("enter rno is to fetch "))
			wa = " http://127.0.0.1:8000/stuop/" + str(r)
			res = requests.get(wa)
			if res.status_code == 404:
				print(r, "does not exists ")
			else:
				data = res.json()
				print(data)
			
		elif op == 4:
			break
		else:
			print("invalid option")
except Exception as e:
	print("issue",e)