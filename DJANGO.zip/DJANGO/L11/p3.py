import requests
try:
	while True:
		op = int(input("1 4 digits , 2 'n' digits and 3 exit "))
		if op == 1:
			wa = " http://127.0.0.1:8000/gln"
			res = requests.get(wa)
			data = res.json()
			num = data['num']
			print("ur lucky number ", num)
		elif op == 2:
			digits = int(input("enter number of digits  "))
			wa = " http://127.0.0.1:8000/gln/" +str(digits)
			res = requests.get(wa)
			data = res.json()
			num = data['num']
			print("ur lucky number ", num)
		elif op == 3:
			break
		else:
			print("invalid option")
except Exception as e:
	print("issue", e)