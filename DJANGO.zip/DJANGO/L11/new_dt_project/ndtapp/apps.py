from django.apps import AppConfig


class NdtappConfig(AppConfig):
    name = 'ndtapp'
