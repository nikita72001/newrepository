from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from datetime import datetime

@api_view(['GET'])
def home(request):
	p = datetime.now()
	msg = "date and time = " +str(p)
	return Response({"msg":msg})

@api_view(['GET'])
def dt(request):
	p = datetime.now().date()
	msg = "date  = " +str(p)
	return Response({"msg":msg})

@api_view(['GET'])
def ti(request):
	p = datetime.now().time()
	msg = "time  = " +str(p)
	return Response({"msg":msg})

# Create your views here.
