from django.apps import AppConfig


class LnappConfig(AppConfig):
    name = 'lnapp'
