from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from random import randrange

@api_view(['GET'])
def gln(request, digits=None):
	if digits is None:
		num = ""
		text = "1234567890"
		for i in range(4):
			num = num + text[randrange(len(text))]
		return Response({"num":num})
	else:	
		num = ""
		text = "1234567890"
		for i in range(digits):
			num = num + text[randrange(len(text))]
		return Response({"num":num})


# Create your views here.
