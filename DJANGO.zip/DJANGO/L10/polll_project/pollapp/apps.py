from django.apps import AppConfig


class PollappConfig(AppConfig):
    name = 'pollapp'
