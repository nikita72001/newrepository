from django.apps import AppConfig


class ScappConfig(AppConfig):
    name = 'scapp'
