from django.shortcuts import render

def home(request):
       if request.GET.get("n") and request.GET.get("s"):
                num = float(request.GET.get("n"))
                res = num * num
                msg = "square = " + str(res)
                return render(request,'home.html',{'msg':msg})
       elif request.GET.get("n") and request.GET.get("c"): 
                num = float(request.GET.get("n"))
                res = num * num * num
                msg = "cube = " + str(res)
                return render(request,'home.html',{'msg':msg})
       else:         
                return render(request,'home.html')  
# Create your views here.
