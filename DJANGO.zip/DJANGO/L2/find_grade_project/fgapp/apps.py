from django.apps import AppConfig


class FgappConfig(AppConfig):
    name = 'fgapp'
