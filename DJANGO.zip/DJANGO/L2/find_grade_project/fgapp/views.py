from django.shortcuts import render


def home(request):
       if request.GET.get("m") and request.GET.get("b1"):
                marks = int(request.GET.get("m"))
                if marks >=80:
                        grade = "Grade A"
                elif marks >=60:
                        grade = "Grade B"
                elif marks >=40:
                        grade = "Grade C"
                else:
                        grade = "Grade D"
                return render(request,'home.html',{'grade':grade})
       else:
                return render(request,'home.html')
                
# Create your views here.
