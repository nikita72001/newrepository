from django.shortcuts import render

def home(request):
       if request.GET.get("n1") and request.GET.get("n2"):
                 num1 = int(request.GET.get("n1"))
                 num2 = int(request.GET.get("n2"))
                 res = num1 + num2
                 return render(request,'home.html',{'res':res})
       else:
                 return render(request,'home.html')

# Create your views here.
