from django.apps import AppConfig


class AddappConfig(AppConfig):
    name = 'addapp'
