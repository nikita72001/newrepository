from django.shortcuts import render

def home(request):
       if request.POST.get('n') and request.POST.get('b1'):
              num = int(request.POST.get("n"))
              res = "even" if num % 2 == 0 else "odd"
              return render(request,'home.html',{'res':res})
       else:
              return render(request,'home.html')

# Create your views here.
