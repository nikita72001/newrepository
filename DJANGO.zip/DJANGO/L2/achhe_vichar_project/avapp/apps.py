from django.apps import AppConfig


class AvappConfig(AppConfig):
    name = 'avapp'
