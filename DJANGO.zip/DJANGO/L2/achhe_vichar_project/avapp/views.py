from django.shortcuts import render
def home(request):
       if request.GET.get("d"):
                return render(request,'home.html',{'p':'dekho'})
       elif request.GET.get("b"):
                return render(request,'home.html',{'p':'bolo'})
       elif request.GET.get("s"):
                return render(request,'home.html',{'p':'suno'})
       else:
                return render(request,'home.html')
# Create your views here.
