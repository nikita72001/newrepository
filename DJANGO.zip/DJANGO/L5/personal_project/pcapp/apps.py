from django.apps import AppConfig


class PcappConfig(AppConfig):
    name = 'pcapp'
