from django import forms
from .models import PcModel
class PcForm(forms.ModelForm):
	class Meta:
		model = PcModel
		fields = '__all__'
