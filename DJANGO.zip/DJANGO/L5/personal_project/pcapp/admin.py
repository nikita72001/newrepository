from django.contrib import admin
from .models import PcModel
admin.site.register(PcModel)

# Register your models here.
