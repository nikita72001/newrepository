from django.shortcuts import render
from .forms import PcForm

def home(request):
	if request.method == "POST":
		f = PcForm(request.POST)
		if f.is_valid():
			f.save()
			fm = PcForm()
			return render(request, "home.html", {"fm":fm, "msg":"will get back to you"})
	else:
		fm = PcForm()
		return render(request, "home.html", {"fm":fm})
		
     

# Create your views here.
