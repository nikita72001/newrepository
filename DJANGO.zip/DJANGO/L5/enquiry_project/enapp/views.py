from django.shortcuts import render
from .forms import EnForm

def home(request):
        if request.method =="POST":
                f = EnForm(request.POST)
                if f.is_valid():
                          f.save()
                          fm = EnForm()
                          return render(request, "home.html",{"fm":fm,"msg":"will get back to you"})
        else:
                fm = EnForm()
                return render(request, "home.html",{"fm":fm})	

# Create your views here.
