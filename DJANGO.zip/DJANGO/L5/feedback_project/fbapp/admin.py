from django.contrib import admin
from .models import FbModel
class FbAdmin(admin.ModelAdmin):
         list_display = ('name','cdt')
         list_filter = ('cdt',)
admin.site.register(FbModel, FbAdmin)

# Register your models here.
