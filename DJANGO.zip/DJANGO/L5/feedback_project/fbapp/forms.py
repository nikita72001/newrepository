from django import forms
from .models import FbModel

class FbForm(forms.ModelForm):
        class Meta:
                model = FbModel
                fields = ['name', 'feedback']
                widgets = {'feedback': forms. Textarea(attrs={'rows':5, 'cols':30})}