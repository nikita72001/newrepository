from django.shortcuts import render
from .forms import FbForm
def home(request):
       if request.method == "POST":
                f = FbForm(request.POST)
                if f.is_valid():
                          f.save()
                          fm = FbForm()
                          return render(request, 'home.html', {'fm':fm, 'msg':'thanx for feedback'})
       else:
                fm = FbForm()
                return render(request, 'home.html',{'fm':fm})

# Create your views here.
