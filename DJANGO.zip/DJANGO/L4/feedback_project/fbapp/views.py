from django.shortcuts import render
from .forms import FbForm
from .models import FbModel

def home(request):
       if request.method == "POST":
                n = request.POST.get("name")
                f = request.POST.get("feedback")
                d = FbModel(name=n, feedback=f)
                d.save()
                fm = FbForm()
                return render(request,"home.html",{'fm':fm,'msg':'thanks for your feedback'})
       else:
                fm = FbForm()
                return render(request,"home.html",{'fm':fm})
# Create your views here.



