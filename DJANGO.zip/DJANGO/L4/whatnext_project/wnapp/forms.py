from django import forms
class WnForm(forms.Form):
        name = forms.CharField()
        options = forms.ChoiceField(choices=[('job',"Job"), ('ms',"MS"), ('mba',"MBA")], widget=forms.RadioSelect())