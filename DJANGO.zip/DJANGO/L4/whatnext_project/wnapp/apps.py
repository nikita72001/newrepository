from django.apps import AppConfig


class WnappConfig(AppConfig):
    name = 'wnapp'
