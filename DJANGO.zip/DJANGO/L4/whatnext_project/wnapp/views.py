from django.shortcuts import render
from .forms import WnForm
from .models import WnModel

def home(request):
       if request.method == "POST":
                n = request.POST.get("name")
                o = request.POST.get("options")
                d = WnModel(name=n, options=o)
                d.save()
                fm = WnForm()
                return render(request,"home.html",{"fm":fm,"msg":"thanks for your options"})
       else:
                fm = WnForm()
                return render(request,"home.html",{"fm":fm})
# Create your views here.





# Create your views here.
