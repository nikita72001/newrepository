from django.contrib import admin
from .models import WnModel
admin.site.register(WnModel)

# Register your models here.
