from django.apps import AppConfig


class EnappConfig(AppConfig):
    name = 'enapp'
