function validate()
{
         var n = document.getElementById("id_name");
         var e = document.getElementById("id_email");
         var p = document.getElementById("id_phone");

         if (n.value.length < 2)
         {
                   alert("name should be only letters ");
                   n.value = "";
                   n.focus();
                   return false;
         }
          var nr = /^[A-Za-z ]+$/
          if (! nr.test(n.value))
         {
                   alert("name should be atleast 2 letters ");
                   n.value = "";
                   n.focus();
                   return false;
         }
          if (p.value.length !=10)
         {
                   alert("invalid phone number ");
                   p.value = "";
                   p.focus();
                   return false;
         }
         return true;
}