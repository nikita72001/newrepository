from django import forms
class EnForm(forms.Form):
        name = forms.CharField(label="enter name ")
        email = forms.EmailField(label="enter email ")
        phone = forms.IntegerField(label="enter phone ")