from django.shortcuts import render
from .forms import EnForm
from .models import EnModel

def home(request):
       if request.method == "POST":
                n = request.POST.get("name")
                e = request.POST.get("email")
                p = request.POST.get("phone")
                print(n, e, p)
                d = EnModel(name=n, email=e, phone=p)
                d.save()
                fm = EnForm()
                return render(request,"home.html",{'fm':fm,'msg':'we will get back to you'})
       fm = EnForm()
       return render(request,"home.html",{'fm':fm})
# Create your views here.
