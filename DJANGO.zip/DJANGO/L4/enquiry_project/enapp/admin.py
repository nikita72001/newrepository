from django.contrib import admin
from .models import EnModel
admin.site.register(EnModel)

# Register your models here.
