from django.apps import AppConfig


class AcappConfig(AppConfig):
    name = 'acapp'
