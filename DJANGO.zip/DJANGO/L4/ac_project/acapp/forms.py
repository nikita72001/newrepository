from django import forms
class AcForm(forms.Form):
        radius = forms.FloatField(label="enter radius", min_value=0,
 widget=forms.NumberInput(attrs={'placeholder':"enter radius>0"}))