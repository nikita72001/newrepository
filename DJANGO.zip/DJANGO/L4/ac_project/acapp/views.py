from django.shortcuts import render
from .forms import AcForm
from math import pi, pow


def home(request):
       if request.GET.get("radius"):
               radius = float(request.GET.get("radius"))
               area = pi * pow(radius, 2)
               circum = 2 * pi * radius
               msg = "area = " + str(area) + "circumference= " + str(circum)
               fm = AcForm()
               return render(request,"home.html",{"fm":fm, 'msg':msg})
       fm = AcForm()
       return render(request,"home.html",{"fm":fm}) 

# Create your views here.
