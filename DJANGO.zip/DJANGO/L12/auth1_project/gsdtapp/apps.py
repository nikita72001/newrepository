from django.apps import AppConfig


class GsdtappConfig(AppConfig):
    name = 'gsdtapp'
