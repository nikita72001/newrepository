from django.apps import AppConfig


class EoappConfig(AppConfig):
    name = 'eoapp'
