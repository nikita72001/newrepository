import requests
import getpass
try:
	t = getpass.getpass(" enter token ")
	tok = 'token ' +str(t)
	he = {'Authorization':tok}
	wa = " http://127.0.0.1:8000/gsdt"
	res = requests.get(wa, headers=he)
	print(res)
	if res.status_code == 403:
		print("invalid token")
	else:
		data = res.json()
		msg = data['msg']
		print(msg)
except Exception as e:
	print("issue", e)