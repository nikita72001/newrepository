from django.apps import AppConfig


class SqrappConfig(AppConfig):
    name = 'sqrapp'
