from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import api_view
from datetime import datetime

@api_view(['GET'])
def gsdt(request):
	dt = datetime.now()
	msg = "server date and time is " +str(dt)
	return Response({"msg":msg})
