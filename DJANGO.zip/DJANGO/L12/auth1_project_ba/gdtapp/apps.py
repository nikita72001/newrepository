from django.apps import AppConfig


class GdtappConfig(AppConfig):
    name = 'gdtapp'
