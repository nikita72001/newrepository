import requests
try:
	he = {'Authorization':'Token e5055b67ddbcfe7f7249ffe40adc5129a51514c8'}
	wa = " http://127.0.0.1:8000/gsdt"
	res = requests.get(wa, headers=he)
	print(res)
	if res.status_code == 403:
		print("invalid token")
	else:
		data = res.json()
		msg = data['msg']
		print(msg)
except Exception as e:
	print("issue", e)