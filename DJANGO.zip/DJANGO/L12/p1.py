import requests
import getpass

try:
	username = input("enter username ")
	password = getpass.getpass("enter password ")
	au = (username, password)
	wa = " http://127.0.0.1:8000/gsdt"
	res = requests.get(wa, auth=au)
	print(res)
	if res.status_code == 403:
		print("invalid credentials ")
	else:
		data = res.json()
		msg = data['msg']
		print(msg)
except Exception as e:
	print("issue", e)